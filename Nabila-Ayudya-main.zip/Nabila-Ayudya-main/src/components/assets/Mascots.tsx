import React from 'react';
import { MascotVariant } from '../../types';

interface MascotProps {
  className?: string;
}

export const MintMascot: React.FC<MascotProps> = ({ className = 'w-24 h-24' }) => (
  <svg
    viewBox="0 0 120 120"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    {/* Ground shadow */}
    <ellipse cx="60" cy="106" rx="28" ry="4" fill="#182334" fillOpacity="0.06" />
    {/* Legs */}
    <rect x="44" y="92" width="4.5" height="12" rx="2.25" fill="#1D2939" />
    <rect x="71.5" y="92" width="4.5" height="12" rx="2.25" fill="#1D2939" />
    {/* Body */}
    <path
      d="M60 18C45.5 18 35.5 27.5 34.5 41.5C34.2 45.8 31.5 49.5 29.8 54.2C26.5 63.3 25.5 76.5 31.2 86.2C36.2 94.6 47.5 97 60 97C72.5 97 83.8 94.6 88.8 86.2C94.5 76.5 93.5 63.3 90.2 54.2C88.5 49.5 85.8 45.8 85.5 41.5C84.5 27.5 74.5 18 60 18Z"
      fill="#C5E0D3"
    />
    {/* Blush */}
    <ellipse cx="42" cy="54" rx="5.5" ry="3.2" fill="#F2B8B5" />
    <ellipse cx="78" cy="54" rx="5.5" ry="3.2" fill="#F2B8B5" />
    {/* Eyes */}
    <circle cx="48.5" cy="48.5" r="3" fill="#1D2939" />
    <circle cx="71.5" cy="48.5" r="3" fill="#1D2939" />
    {/* Smile */}
    <path
      d="M54 51.5C55.5 56 64.5 56 66 51.5"
      stroke="#1D2939"
      strokeWidth="2.8"
      strokeLinecap="round"
    />
    {/* Arms */}
    <path
      d="M32 62C33 70 40 75 47 76"
      stroke="#1D2939"
      strokeWidth="2.6"
      strokeLinecap="round"
    />
    <path
      d="M88 62C87 70 80 75 73 76"
      stroke="#1D2939"
      strokeWidth="2.6"
      strokeLinecap="round"
    />
  </svg>
);

export const PeriwinkleMascot: React.FC<MascotProps> = ({ className = 'w-24 h-24' }) => (
  <svg
    viewBox="0 0 120 120"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    {/* Ground shadow */}
    <ellipse cx="60" cy="106" rx="28" ry="4" fill="#182334" fillOpacity="0.06" />
    {/* Legs */}
    <rect x="44" y="92" width="4.5" height="12" rx="2.25" fill="#1D2939" />
    <rect x="71.5" y="92" width="4.5" height="12" rx="2.25" fill="#1D2939" />
    {/* Ears */}
    <circle cx="38" cy="27" r="9.5" fill="#9BB0EC" />
    <circle cx="82" cy="27" r="9.5" fill="#9BB0EC" />
    {/* Body */}
    <path
      d="M60 22C42 22 29 34 29 56C29 79 34 96 60 96C86 96 91 79 91 56C91 34 78 22 60 22Z"
      fill="#9BB0EC"
    />
    {/* Blush */}
    <ellipse cx="42" cy="54" rx="5.5" ry="3.2" fill="#F2B8B5" />
    <ellipse cx="78" cy="54" rx="5.5" ry="3.2" fill="#F2B8B5" />
    {/* Eyes */}
    <circle cx="48.5" cy="48.5" r="3" fill="#1D2939" />
    <circle cx="71.5" cy="48.5" r="3" fill="#1D2939" />
    {/* Smile */}
    <path
      d="M54 51.5C55.5 56 64.5 56 66 51.5"
      stroke="#1D2939"
      strokeWidth="2.8"
      strokeLinecap="round"
    />
    {/* Arms */}
    <path
      d="M32 62C33 70 40 75 47 76"
      stroke="#1D2939"
      strokeWidth="2.6"
      strokeLinecap="round"
    />
    <path
      d="M88 62C87 70 80 75 73 76"
      stroke="#1D2939"
      strokeWidth="2.6"
      strokeLinecap="round"
    />
  </svg>
);

export const DuoMascots: React.FC<{ className?: string }> = ({ className = 'w-44 h-24' }) => (
  <div className={`inline-flex items-center justify-center gap-2 ${className}`}>
    <PeriwinkleMascot className="w-20 h-20" />
    <MintMascot className="w-20 h-20" />
  </div>
);

interface BuddyAvatarProps {
  variant: MascotVariant;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export const BuddyAvatar: React.FC<BuddyAvatarProps> = ({
  variant,
  size = 'md',
  className = '',
}) => {
  const sizeClasses = {
    sm: 'w-9 h-9',
    md: 'w-12 h-12',
    lg: 'w-14 h-14',
    xl: 'w-16 h-16',
  }[size];

  const mascotSize = {
    sm: 'w-8 h-8',
    md: 'w-11 h-11',
    lg: 'w-12 h-12',
    xl: 'w-14 h-14',
  }[size];

  const bgClass = variant === 'periwinkle' ? 'bg-[#ECF0FB]' : 'bg-[#E9F4EE]';

  return (
    <div
      className={`${sizeClasses} ${bgClass} rounded-full flex items-center justify-center shrink-0 overflow-hidden ${className}`}
    >
      {variant === 'periwinkle' ? (
        <PeriwinkleMascot className={mascotSize} />
      ) : (
        <MintMascot className={mascotSize} />
      )}
    </div>
  );
};

export const QrisIllustrationSvg: React.FC<{ className?: string }> = ({
  className = 'w-48 h-48',
}) => (
  <svg
    viewBox="0 0 210 210"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    role="img"
    aria-label="Kode QRIS ilustrasi TitipCerita"
  >
    <rect width="210" height="210" rx="16" fill="#FFFFFF" />
    <g fill="#1D2939">
      {/* Top-Left Finder */}
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M15 15H65V65H15V15ZM23 23V57H57V23H23Z"
      />
      <rect x="31" y="31" width="18" height="18" />

      {/* Top-Right Finder */}
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M145 15H195V65H145V15ZM153 23V57H187V23H153Z"
      />
      <rect x="161" y="31" width="18" height="18" />

      {/* Bottom-Left Finder */}
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M15 145H65V195H15V145ZM23 153V187H57V153H23Z"
      />
      <rect x="31" y="161" width="18" height="18" />

      {/* Decorative symmetric QR modules matching Figma QRIS */}
      <rect x="77" y="15" width="16" height="8" />
      <rect x="115" y="15" width="18" height="8" />
      <rect x="77" y="29" width="8" height="14" />
      <rect x="93" y="29" width="12" height="12" />
      <rect x="111" y="35" width="14" height="14" />
      <rect x="85" y="45" width="10" height="10" />
      <rect x="103" y="45" width="8" height="8" />
      <rect x="125" y="51" width="14" height="14" />
      <rect x="77" y="55" width="12" height="12" />

      <rect x="15" y="77" width="8" height="12" />
      <rect x="31" y="77" width="14" height="8" />
      <rect x="53" y="77" width="12" height="12" />
      <rect x="23" y="93" width="14" height="14" />
      <rect x="43" y="93" width="10" height="10" />
      <rect x="15" y="113" width="12" height="12" />
      <rect x="35" y="113" width="14" height="14" />
      <rect x="53" y="125" width="12" height="10" />

      {/* Center geometric blocks */}
      <rect x="79" y="79" width="12" height="12" />
      <rect x="97" y="79" width="16" height="8" />
      <rect x="121" y="79" width="12" height="12" />
      <rect x="79" y="97" width="8" height="16" />
      <rect x="95" y="95" width="20" height="20" rx="2" />
      <rect x="123" y="97" width="10" height="16" />
      <rect x="79" y="121" width="14" height="12" />
      <rect x="101" y="123" width="14" height="10" />
      <rect x="121" y="121" width="12" height="12" />

      {/* Right & Bottom modules */}
      <rect x="145" y="77" width="12" height="12" />
      <rect x="165" y="77" width="14" height="10" />
      <rect x="187" y="77" width="8" height="16" />
      <rect x="153" y="95" width="14" height="14" />
      <rect x="175" y="97" width="12" height="12" />
      <rect x="145" y="115" width="10" height="14" />
      <rect x="165" y="115" width="14" height="12" />
      <rect x="187" y="115" width="8" height="18" />

      <rect x="77" y="145" width="12" height="12" />
      <rect x="97" y="145" width="14" height="10" />
      <rect x="121" y="145" width="12" height="12" />
      <rect x="85" y="163" width="16" height="14" />
      <rect x="109" y="163" width="12" height="12" />
      <rect x="129" y="163" width="10" height="14" />
      <rect x="77" y="185" width="14" height="10" />
      <rect x="101" y="185" width="14" height="10" />
      <rect x="123" y="183" width="12" height="12" />

      <rect x="145" y="145" width="14" height="14" />
      <rect x="167" y="145" width="10" height="10" />
      <rect x="185" y="145" width="10" height="16" />
      <rect x="145" y="169" width="12" height="12" />
      <rect x="165" y="165" width="14" height="14" />
      <rect x="185" y="171" width="10" height="10" />
      <rect x="145" y="187" width="14" height="8" />
      <rect x="171" y="185" width="16" height="10" />
    </g>
  </svg>
);
