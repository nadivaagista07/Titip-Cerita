import React from 'react';
import { ArrowLeft, MoreHorizontal } from 'lucide-react';

interface TopBarProps {
  title: string;
  onBack?: () => void;
  onMore?: () => void;
  rightSlot?: React.ReactNode;
}

export const TopBar: React.FC<TopBarProps> = ({ title, onBack, onMore, rightSlot }) => {
  return (
    <header className="flex items-center justify-between h-14 px-5 md:px-0 mb-2">
      <div className="flex items-center gap-3.5 min-w-0">
        {onBack && (
          <button
            type="button"
            onClick={onBack}
            aria-label="Kembali"
            className="w-10 h-10 rounded-full bg-white/90 hover:bg-white flex items-center justify-center text-[#182334] shadow-[0_2px_10px_rgba(24,35,52,0.05)] transition-colors cursor-pointer shrink-0"
          >
            <ArrowLeft className="w-5 h-5" strokeWidth={2} />
          </button>
        )}
        <h1 className="text-[17px] font-bold text-[#182334] tracking-tight truncate">
          {title}
        </h1>
      </div>

      {rightSlot ? (
        rightSlot
      ) : onMore ? (
        <button
          type="button"
          onClick={onMore}
          aria-label="Opsi lainnya"
          className="w-10 h-10 rounded-full hover:bg-white/60 flex items-center justify-center text-[#182334] transition-colors cursor-pointer shrink-0"
        >
          <MoreHorizontal className="w-5 h-5" />
        </button>
      ) : (
        <div className="w-10" />
      )}
    </header>
  );
};
