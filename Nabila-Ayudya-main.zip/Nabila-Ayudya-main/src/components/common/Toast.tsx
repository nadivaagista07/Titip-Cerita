import React from 'react';
import { CheckCircle2, Info } from 'lucide-react';

interface ToastProps {
  message: string | null;
  type?: 'success' | 'info';
}

export const Toast: React.FC<ToastProps> = ({ message, type = 'success' }) => {
  if (!message) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed top-5 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2.5 px-4 py-3 rounded-full bg-[#182334] text-white text-sm font-medium shadow-xl transition-all duration-200 max-w-[90vw]"
    >
      {type === 'success' ? (
        <CheckCircle2 className="w-4 h-4 text-[#A3D9BE] shrink-0" />
      ) : (
        <Info className="w-4 h-4 text-[#93A8E6] shrink-0" />
      )}
      <span className="truncate">{message}</span>
    </div>
  );
};
