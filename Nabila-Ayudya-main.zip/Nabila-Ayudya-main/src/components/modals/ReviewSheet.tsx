import React, { useState } from 'react';
import { ArrowLeft, Check, MoreHorizontal, Star, X } from 'lucide-react';
import { SessionItem, SessionReview } from '../../types';
import { BuddyAvatar, MintMascot } from '../assets/Mascots';

interface ReviewSheetProps {
  session: SessionItem;
  readOnly?: boolean;
  onSubmit: (sessionId: string, review: SessionReview) => void;
  onClose: () => void;
}

const RATING_LABELS: Record<number, string> = {
  1: '1 dari 5 · Kurang nyaman',
  2: '2 dari 5 · Biasa saja',
  3: '3 dari 5 · Cukup membantu',
  4: '4 dari 5 · Hangat dan membantu',
  5: '5 dari 5 · Nyaman banget',
};

const AVAILABLE_TAGS = [
  'Pendengar baik',
  'Tidak menghakimi',
  'Sabar',
  'Bikin tenang',
];

export const ReviewSheet: React.FC<ReviewSheetProps> = ({
  session,
  readOnly = false,
  onSubmit,
  onClose,
}) => {
  const existing = session.review;
  const [rating, setRating] = useState<number>(existing?.rating ?? 5);
  const [selectedTags, setSelectedTags] = useState<string[]>(
    existing?.tags ?? ['Pendengar baik', 'Tidak menghakimi']
  );
  const [comment, setComment] = useState<string>(
    existing?.comment ??
      'Makasih sudah mendengarkan tanpa buru-buru. Aku jadi lebih lega dan tahu mau mulai dari mana.'
  );
  const [anonymous, setAnonymous] = useState<boolean>(existing?.anonymous ?? true);

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(session.id, {
      rating,
      tags: selectedTags,
      comment: comment.trim(),
      anonymous,
      submittedAt: '20 Okt 2026',
    });
  };

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col justify-end md:justify-center md:items-center bg-[#D6E5DE]/95 backdrop-blur-sm overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="review-sheet-title"
    >
      {/* Top Sesi selesai header & Mint mascot backdrop matching Figma */}
      <div className="w-full max-w-[460px] mx-auto pt-4 px-5 flex flex-col items-center shrink-0">
        <div className="w-full flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              aria-label="Kembali"
              className="w-10 h-10 rounded-full bg-white/75 hover:bg-white flex items-center justify-center text-[#182334] transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <span className="text-[17px] font-bold text-[#182334]">
              Sesi selesai
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup"
            className="w-10 h-10 rounded-full hover:bg-white/40 flex items-center justify-center text-[#182334] cursor-pointer"
          >
            <MoreHorizontal className="w-5 h-5" />
          </button>
        </div>

        <MintMascot className="w-28 h-28 mb-2" />
      </div>

      {/* Bottom Sheet / Card */}
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-[460px] mx-auto bg-white rounded-t-[32px] md:rounded-[32px] px-6 pt-3 pb-7 shadow-[0_-10px_40px_rgba(24,35,52,0.10)]"
      >
        {/* Drag Handle */}
        <div className="w-11 h-1 rounded-full bg-slate-200 mx-auto mb-5" />

        <div className="flex items-start justify-between gap-3">
          <div>
            <h2
              id="review-sheet-title"
              className="text-[22px] font-extrabold text-[#182334] tracking-tight leading-snug"
            >
              Gimana rasanya tadi?
            </h2>
            <p className="text-[13px] text-[#526071] mt-1">
              Ulasanmu membantu teman lain memilih buddy.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup lembar ulasan"
            className="w-9 h-9 rounded-full hover:bg-slate-100 flex items-center justify-center text-[#526071] cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Buddy Session Summary */}
        <div className="flex items-center gap-3 mt-5">
          <BuddyAvatar variant={session.buddyMascot} size="md" />
          <div>
            <div className="text-[14px] font-bold text-[#182334]">
              {session.buddyName} · {session.type} {session.durationLabel}
            </div>
            <div className="text-[12px] text-[#64748B] mt-0.5">
              {session.dateLabel} · {session.timeLabel}
            </div>
          </div>
        </div>

        {/* Interactive Stars */}
        <div className="mt-6 flex flex-col items-center">
          <div className="flex items-center gap-3" role="radiogroup" aria-label="Penilaian bintang">
            {[1, 2, 3, 4, 5].map((star) => {
              const active = star <= rating;
              return (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  aria-label={`${star} bintang`}
                  className="p-1 transition-transform hover:scale-110 active:scale-95 cursor-pointer"
                >
                  <Star
                    className={`w-8 h-8 transition-colors ${
                      active
                        ? 'fill-[#182334] text-[#182334]'
                        : 'fill-slate-200 text-slate-200'
                    }`}
                  />
                </button>
              );
            })}
          </div>
          <p className="text-[13px] font-medium text-[#526071] mt-2.5 tabular-nums">
            {RATING_LABELS[rating]}
          </p>
        </div>

        {/* Selectable Trait Pills */}
        <div className="mt-5 flex flex-wrap gap-2">
          {AVAILABLE_TAGS.map((tag) => {
            const active = selectedTags.includes(tag);
            return (
              <button
                key={tag}
                type="button"
                onClick={() => toggleTag(tag)}
                className={`px-4 py-2 rounded-full text-[13px] font-semibold transition-all cursor-pointer ${
                  active
                    ? 'bg-[#93A8E6] text-[#182334]'
                    : 'bg-[#F2F5FB] text-[#526071] hover:bg-[#E5ECFA]'
                }`}
              >
                {tag}
              </button>
            );
          })}
        </div>

        {/* Comment Textarea */}
        <div className="mt-4 bg-[#F4F7FC] rounded-2xl p-4 focus-within:ring-2 focus-within:ring-[#93A8E6]">
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value.slice(0, 500))}
            rows={3}
            maxLength={500}
            placeholder="Ceritakan pengalamanmu bersama buddy ini..."
            className="w-full bg-transparent text-[13.5px] leading-relaxed text-[#182334] placeholder:text-[#94A3B8] resize-none focus:outline-none"
          />
          <div className="text-right text-[11px] font-medium text-[#64748B] tabular-nums mt-1">
            {comment.length}/500
          </div>
        </div>

        {/* Anonymous Checkbox */}
        <label className="mt-4 flex items-center gap-2.5 cursor-pointer select-none">
          <button
            type="button"
            role="checkbox"
            aria-checked={anonymous}
            onClick={() => setAnonymous((prev) => !prev)}
            className={`w-5 h-5 rounded-md border flex items-center justify-center transition-colors cursor-pointer ${
              anonymous
                ? 'bg-white border-[#182334] text-[#182334]'
                : 'bg-white border-slate-300 text-transparent'
            }`}
          >
            <Check className="w-3.5 h-3.5" strokeWidth={2.8} />
          </button>
          <span className="text-[13px] text-[#334155]">
            Tampilkan ulasan dengan nama samaran
          </span>
        </label>

        {/* Actions */}
        <div className="mt-6 space-y-3">
          <button
            type="submit"
            className="w-full h-12 rounded-full tc-btn-primary text-[15px] cursor-pointer"
          >
            {readOnly ? 'Simpan perubahan ulasan' : 'Kirim ulasan'}
          </button>
          <button
            type="button"
            onClick={onClose}
            className="w-full py-2 text-[13px] font-semibold text-[#334155] hover:text-[#182334] cursor-pointer"
          >
            Nanti saja
          </button>
        </div>
      </form>
    </div>
  );
};
