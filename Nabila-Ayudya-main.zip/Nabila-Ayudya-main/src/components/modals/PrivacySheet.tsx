import React, { useState } from 'react';
import {
  BookOpen,
  ChevronRight,
  Download,
  FileText,
  HeartHandshake,
  HelpCircle,
  Shield,
  X,
} from 'lucide-react';
import { UserProfile } from '../../types';

interface PrivacySheetProps {
  user: UserProfile;
  onToggleAnonymous: () => void;
  onOpenBantuanProfesional: () => void;
  onResetDemoData: () => void;
  onShowToast: (msg: string) => void;
  onClose: () => void;
}

type SubDoc = null | 'manage' | 'guidelines' | 'terms' | 'help' | 'logout' | 'delete';

export const PrivacySheet: React.FC<PrivacySheetProps> = ({
  user,
  onToggleAnonymous,
  onOpenBantuanProfesional,
  onResetDemoData,
  onShowToast,
  onClose,
}) => {
  const [subDoc, setSubDoc] = useState<SubDoc>(null);

  const handleDownloadData = () => {
    const payload = {
      exportedAt: new Date().toISOString(),
      account: {
        name: user.name,
        email: user.email,
        age: user.age,
        joinedLabel: user.joinedLabel,
        interests: user.interests,
        anonymousByDefault: user.anonymousByDefault,
      },
      note: 'Riwayat percakapan sesi tidak disimpan untuk konsumsi publik.',
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'data-akun-titipcerita.json';
    link.click();
    URL.revokeObjectURL(url);
    onShowToast('Salinan data akun berhasil diunduh.');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col justify-end md:justify-center md:items-center bg-[#182334]/30 backdrop-blur-[2px]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="privacy-sheet-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-[440px] mx-auto bg-[#EBF1FA] rounded-t-[32px] md:rounded-[32px] px-4 pt-3 pb-7 shadow-2xl max-h-[88dvh] overflow-y-auto">
        {/* Top bar indicator */}
        <div className="flex items-center justify-between px-2 mb-3">
          <div className="w-8" />
          <div className="w-24 h-1 rounded-full bg-[#182334]/80" />
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup panel privasi"
            className="w-8 h-8 rounded-full hover:bg-white/70 flex items-center justify-center text-[#526071] cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {subDoc === null ? (
          <div className="space-y-4">
            {/* Main Privacy Card */}
            <div className="bg-white rounded-[24px] p-5 shadow-[0_4px_20px_rgba(24,35,52,0.04)]">
              <h2
                id="privacy-sheet-title"
                className="text-[20px] font-extrabold text-[#182334] tracking-tight"
              >
                Privasi ada di tanganmu.
              </h2>
              <p className="text-[13.5px] leading-relaxed text-[#475569] mt-3">
                Gunakan nama samaran di komunitas dan ulasan. Jangan membagikan
                alamat, nomor pribadi, atau informasi sensitif dalam percakapan.
              </p>
              <p className="text-[13.5px] leading-relaxed text-[#475569] mt-3">
                Akses data dibatasi sesuai Kebijakan Privasi. Kamu bisa meminta
                akses, koreksi, atau penghapusan data akun.
              </p>

              <button
                type="button"
                onClick={() => setSubDoc('manage')}
                className="mt-5 w-full h-12 rounded-full border border-slate-200 bg-white hover:bg-slate-50 flex items-center justify-center gap-2.5 text-[14px] font-bold text-[#182334] transition-colors cursor-pointer"
              >
                <Shield className="w-4 h-4 text-[#334155]" />
                <span>Kelola data &amp; privasi</span>
              </button>
            </div>

            {/* Links Card */}
            <div className="bg-white rounded-[24px] overflow-hidden shadow-[0_4px_20px_rgba(24,35,52,0.04)] divide-y divide-slate-100">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenBantuanProfesional();
                }}
                className="w-full flex items-center justify-between px-5 py-4 hover:bg-slate-50/80 transition-colors cursor-pointer text-left"
              >
                <span className="flex items-center gap-3.5 text-[14px] font-semibold text-[#182334]">
                  <HeartHandshake className="w-[18px] h-[18px] text-[#475569]" />
                  <span>Bantuan Profesional</span>
                </span>
                <ChevronRight className="w-4 h-4 text-[#64748B]" />
              </button>

              <button
                type="button"
                onClick={() => setSubDoc('guidelines')}
                className="w-full flex items-center justify-between px-5 py-4 hover:bg-slate-50/80 transition-colors cursor-pointer text-left"
              >
                <span className="flex items-center gap-3.5 text-[14px] font-semibold text-[#182334]">
                  <BookOpen className="w-[18px] h-[18px] text-[#475569]" />
                  <span>Panduan komunitas</span>
                </span>
                <ChevronRight className="w-4 h-4 text-[#64748B]" />
              </button>

              <button
                type="button"
                onClick={() => setSubDoc('terms')}
                className="w-full flex items-center justify-between px-5 py-4 hover:bg-slate-50/80 transition-colors cursor-pointer text-left"
              >
                <span className="flex items-center gap-3.5 text-[14px] font-semibold text-[#182334]">
                  <FileText className="w-[18px] h-[18px] text-[#475569]" />
                  <span>Ketentuan &amp; Kebijakan Privasi</span>
                </span>
                <ChevronRight className="w-4 h-4 text-[#64748B]" />
              </button>

              <button
                type="button"
                onClick={() => setSubDoc('help')}
                className="w-full flex items-center justify-between px-5 py-4 hover:bg-slate-50/80 transition-colors cursor-pointer text-left"
              >
                <span className="flex items-center gap-3.5 text-[14px] font-semibold text-[#182334]">
                  <HelpCircle className="w-[18px] h-[18px] text-[#475569]" />
                  <span>Pusat bantuan</span>
                </span>
                <ChevronRight className="w-4 h-4 text-[#64748B]" />
              </button>
            </div>

            {/* Footer Account Actions */}
            <div className="flex items-center justify-between px-3 pt-2 text-[13px]">
              <button
                type="button"
                onClick={() => setSubDoc('logout')}
                className="font-bold text-[#182334] hover:underline cursor-pointer"
              >
                Keluar akun
              </button>
              <button
                type="button"
                onClick={() => setSubDoc('delete')}
                className="font-medium text-[#526071] hover:text-rose-600 cursor-pointer"
              >
                Hapus akun
              </button>
            </div>

            <p className="text-center text-[11.5px] text-[#64748B] pt-1">
              TitipCerita v1.0 · Dibuat untuk saling menemani.
            </p>
          </div>
        ) : (
          <div className="bg-white rounded-[24px] p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-[17px] font-extrabold text-[#182334]">
                {subDoc === 'manage' && 'Kelola data & privasi'}
                {subDoc === 'guidelines' && 'Panduan komunitas'}
                {subDoc === 'terms' && 'Ketentuan & Kebijakan Privasi'}
                {subDoc === 'help' && 'Pusat bantuan'}
                {subDoc === 'logout' && 'Keluar dari akun?'}
                {subDoc === 'delete' && 'Hapus akun & data?'}
              </h3>
              <button
                type="button"
                onClick={() => setSubDoc(null)}
                className="text-[13px] font-bold text-[#526071] hover:text-[#182334] cursor-pointer"
              >
                Kembali
              </button>
            </div>

            {subDoc === 'manage' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3.5 rounded-2xl bg-[#F4F7FC]">
                  <div className="pr-3">
                    <div className="text-[13.5px] font-bold text-[#182334]">
                      Gunakan nama samaran otomatis
                    </div>
                    <div className="text-[12px] text-[#526071] mt-0.5">
                      Sembunyikan nama aslimu di komunitas &amp; ulasan buddy.
                    </div>
                  </div>
                  <button
                    type="button"
                    role="switch"
                    aria-checked={user.anonymousByDefault}
                    onClick={onToggleAnonymous}
                    className={`w-12 h-7 rounded-full transition-colors p-1 shrink-0 cursor-pointer ${
                      user.anonymousByDefault ? 'bg-[#93A8E6]' : 'bg-slate-300'
                    }`}
                  >
                    <span
                      className={`block w-5 h-5 rounded-full bg-white shadow transition-transform ${
                        user.anonymousByDefault ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handleDownloadData}
                  className="w-full h-11 rounded-full border border-slate-200 hover:bg-slate-50 flex items-center justify-center gap-2 text-[13.5px] font-bold text-[#182334] cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Unduh salinan data akun (JSON)</span>
                </button>
              </div>
            )}

            {subDoc === 'guidelines' && (
              <ul className="space-y-2.5 text-[13.5px] text-[#475569] leading-relaxed">
                <li>1. Saling menghormati dan mendengarkan tanpa menghakimi.</li>
                <li>2. Jaga kerahasiaan identitas pribadi—tidak perlu berbagi nomor HP atau alamat.</li>
                <li>3. Buddy adalah teman sebaya, bukan pengganti psikolog klinis atau layanan medis darurat.</li>
              </ul>
            )}

            {subDoc === 'terms' && (
              <p className="text-[13.5px] text-[#475569] leading-relaxed">
                TitipCerita menyimpan data profil dan jadwal sesimu secara lokal untuk kelancaran layanan. Percakapan privat tidak pernah dipublikasikan ke ruang komunitas maupun pihak ketiga.
              </p>
            )}

            {subDoc === 'help' && (
              <div className="space-y-2.5 text-[13.5px] text-[#475569] leading-relaxed">
                <p>
                  Butuh bantuan teknis soal jadwal atau pembayaran? Kamu bisa mereset data sesi demo atau menghubungi tim dukungan di{' '}
                  <span className="font-semibold text-[#182334]">halo@titipcerita.id</span>.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    onResetDemoData();
                    setSubDoc(null);
                    onClose();
                  }}
                  className="w-full h-10 rounded-full bg-[#F4F7FC] hover:bg-[#E7EEFA] text-[13px] font-bold text-[#182334] cursor-pointer"
                >
                  Pulihkan data sesi awal
                </button>
              </div>
            )}

            {subDoc === 'logout' && (
              <div className="space-y-3">
                <p className="text-[13.5px] text-[#475569]">
                  Kamu akan keluar dari sesi perangkat ini. Jadwal sesimu tetap tersimpan aman.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    onShowToast('Berhasil keluar sementara. Sampai ketemu lagi, Alya.');
                    setSubDoc(null);
                    onClose();
                  }}
                  className="w-full h-11 rounded-full tc-btn-primary text-[14px] cursor-pointer"
                >
                  Konfirmasi keluar
                </button>
              </div>
            )}

            {subDoc === 'delete' && (
              <div className="space-y-3">
                <p className="text-[13.5px] text-[#475569]">
                  Penghapusan akun akan menghapus preferensi dan riwayat lokalmu. Tindakan ini dapat dibatalkan dengan memulihkan data demo.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    onResetDemoData();
                    onShowToast('Permintaan penghapusan diproses dan sesi disegarkan.');
                    setSubDoc(null);
                    onClose();
                  }}
                  className="w-full h-11 rounded-full bg-rose-100 hover:bg-rose-200 text-rose-900 font-bold text-[14px] cursor-pointer"
                >
                  Hapus data lokal sekarang
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
