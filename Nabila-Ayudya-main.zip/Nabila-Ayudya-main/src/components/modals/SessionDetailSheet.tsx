import React, { useState } from 'react';
import { Calendar, Clock, MessageCircle, Timer, X } from 'lucide-react';
import { formatRupiah } from '../../data/mockData';
import { SessionItem } from '../../types';
import { BuddyAvatar } from '../assets/Mascots';

interface SessionDetailSheetProps {
  session: SessionItem;
  onStartSession: (session: SessionItem) => void;
  onReschedule: (sessionId: string, newTimeLabel: string) => void;
  onCancelSession: (sessionId: string) => void;
  onClose: () => void;
}

const TIME_SLOTS = ['19.00–19.30 WIB', '20.00–21.00 WIB', '21.00–22.00 WIB'];

export const SessionDetailSheet: React.FC<SessionDetailSheetProps> = ({
  session,
  onStartSession,
  onReschedule,
  onCancelSession,
  onClose,
}) => {
  const [rescheduling, setRescheduling] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState(session.timeLabel);

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col justify-end md:justify-center md:items-center bg-[#182334]/30 backdrop-blur-[2px]"
      role="dialog"
      aria-modal="true"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-[440px] mx-auto bg-white rounded-t-[32px] md:rounded-[32px] px-6 pt-3 pb-7 shadow-2xl">
        <div className="w-10 h-1 rounded-full bg-slate-200 mx-auto mb-5" />

        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3.5">
            <BuddyAvatar variant={session.buddyMascot} size="lg" />
            <div>
              <h2 className="text-[19px] font-extrabold text-[#182334]">
                {session.buddyName} {session.buddyVerified ? '✓' : ''}
              </h2>
              <p className="text-[13px] text-[#526071]">
                {session.type} · {session.durationLabel}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup detail sesi"
            className="w-9 h-9 rounded-full hover:bg-slate-100 flex items-center justify-center text-[#526071] cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-5 rounded-2xl bg-[#F4F7FC] p-4 space-y-2.5 text-[13.5px]">
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-2 text-[#526071]">
              <Calendar className="w-4 h-4" />
              <span>Jadwal</span>
            </span>
            <span className="font-semibold text-[#182334]">
              {session.dateLabel} · {session.timeLabel}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-2 text-[#526071]">
              <Clock className="w-4 h-4" />
              <span>Pembayaran</span>
            </span>
            <span className="font-semibold text-[#182334] tabular-nums">
              {formatRupiah(session.price)} · Sudah dibayar ({session.paymentMethodLabel})
            </span>
          </div>
          <div className="flex items-center justify-between text-[12px] text-[#64748B]">
            <span>ID pemesanan</span>
            <span className="font-semibold tabular-nums">{session.orderId}</span>
          </div>
        </div>

        {rescheduling ? (
          <div className="mt-5 space-y-3">
            <div className="text-[13px] font-bold text-[#182334]">
              Pilih jam baru untuk {session.dateLabel}
            </div>
            <div className="grid grid-cols-1 gap-2">
              {TIME_SLOTS.map((slot) => (
                <button
                  key={slot}
                  type="button"
                  onClick={() => setSelectedSlot(slot)}
                  className={`px-4 py-2.5 rounded-2xl text-[13px] font-semibold text-left border transition-colors cursor-pointer ${
                    selectedSlot === slot
                      ? 'bg-[#DCE4FA] border-[#93A8E6] text-[#182334]'
                      : 'bg-white border-slate-200 text-[#475569]'
                  }`}
                >
                  {slot}
                </button>
              ))}
            </div>
            <div className="flex gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => setRescheduling(false)}
                className="flex-1 h-11 rounded-full border border-slate-200 text-[13.5px] font-bold text-[#475569] cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  onReschedule(session.id, selectedSlot);
                  setRescheduling(false);
                }}
                className="flex-1 h-11 rounded-full tc-btn-primary text-[13.5px] cursor-pointer"
              >
                Simpan jadwal
              </button>
            </div>
          </div>
        ) : (
          <div className="mt-6 space-y-2.5">
            <button
              type="button"
              onClick={() => onStartSession(session)}
              className="w-full h-12 rounded-full tc-btn-primary text-[14.5px] flex items-center justify-center gap-2 cursor-pointer"
            >
              {session.type === 'Study' ? (
                <>
                  <Timer className="w-4 h-4" />
                  <span>Masuk Study Room (Pomodoro)</span>
                </>
              ) : (
                <>
                  <MessageCircle className="w-4 h-4" />
                  <span>Mulai sesi chat sekarang</span>
                </>
              )}
            </button>

            <div className="flex gap-2.5">
              <button
                type="button"
                onClick={() => setRescheduling(true)}
                className="flex-1 h-11 rounded-full border border-slate-200 hover:bg-slate-50 text-[13.5px] font-bold text-[#182334] cursor-pointer"
              >
                Ubah jadwal
              </button>
              <button
                type="button"
                onClick={() => onCancelSession(session.id)}
                className="flex-1 h-11 rounded-full border border-slate-200 hover:bg-rose-50 text-[13.5px] font-semibold text-[#526071] hover:text-rose-700 cursor-pointer"
              >
                Batalkan sesi
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
