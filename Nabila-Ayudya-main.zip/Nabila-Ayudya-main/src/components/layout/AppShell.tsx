import React from 'react';
import { CalendarHeart, HeartHandshake, Home, User, Users } from 'lucide-react';
import { AppRoute, UserProfile } from '../../types';
import { BuddyAvatar, PeriwinkleMascot } from '../assets/Mascots';

interface AppShellProps {
  currentRoute: AppRoute;
  onNavigate: (route: AppRoute) => void;
  user: UserProfile;
  ongoingCount: number;
  children: React.ReactNode;
}

const PRIMARY_TABS: { id: AppRoute; label: string; icon: React.FC<{ className?: string }> }[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'komunitas', label: 'Komunitas', icon: Users },
  { id: 'sesi-saya', label: 'Sesi Saya', icon: CalendarHeart },
  { id: 'profil', label: 'Profil', icon: User },
];

const IMMERSIVE_ROUTES: AppRoute[] = [
  'payment',
  'payment-bank',
  'payment-qris',
  'payment-success',
  'chat-room',
  'study-room',
  'bantuan-profesional',
];

export const AppShell: React.FC<AppShellProps> = ({
  currentRoute,
  onNavigate,
  user,
  ongoingCount,
  children,
}) => {
  const isImmersive = IMMERSIVE_ROUTES.includes(currentRoute);

  return (
    <div className="min-h-dvh tc-canvas flex flex-col md:flex-row md:max-w-6xl md:mx-auto md:px-6 md:py-6 md:gap-6">
      {/* Desktop / Tablet Sidebar Rail */}
      <aside className="hidden md:flex md:flex-col md:w-64 lg:w-68 shrink-0">
        <div className="sticky top-6 bg-white/90 backdrop-blur-md rounded-[28px] p-5 shadow-[0_6px_28px_rgba(24,35,52,0.05)] flex flex-col justify-between min-h-[calc(100dvh-3rem)]">
          <div>
            {/* Brand Lockup */}
            <button
              type="button"
              onClick={() => onNavigate('home')}
              className="flex items-center gap-3 w-full text-left mb-7 cursor-pointer group"
            >
              <div className="w-11 h-11 rounded-2xl bg-[#ECF0FB] flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                <PeriwinkleMascot className="w-9 h-9" />
              </div>
              <div>
                <div className="text-[18px] font-extrabold text-[#182334] tracking-tight leading-tight">
                  TitipCerita
                </div>
                <div className="text-[12px] text-[#526071]">
                  Teman cerita &amp; belajar
                </div>
              </div>
            </button>

            {/* Primary Nav */}
            <nav aria-label="Navigasi utama" className="space-y-1.5">
              {PRIMARY_TABS.map((tab) => {
                const Icon = tab.icon;
                const active = currentRoute === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => onNavigate(tab.id)}
                    className={`w-full flex items-center justify-between px-4 py-3 rounded-2xl text-[14px] font-semibold transition-all cursor-pointer ${
                      active
                        ? 'bg-[#93A8E6] text-[#182334] shadow-sm'
                        : 'text-[#475569] hover:bg-[#F3F6FC] hover:text-[#182334]'
                    }`}
                  >
                    <span className="flex items-center gap-3">
                      <Icon className="w-[18px] h-[18px]" />
                      <span>{tab.label}</span>
                    </span>
                    {tab.id === 'sesi-saya' && ongoingCount > 0 && (
                      <span
                        className={`text-[11px] font-bold px-2 py-0.5 rounded-full tabular-nums ${
                          active
                            ? 'bg-white/80 text-[#182334]'
                            : 'bg-[#DCE4FA] text-[#182334]'
                        }`}
                      >
                        {ongoingCount} aktif
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>

            {/* Quick Professional Support Link */}
            <div className="mt-6 pt-5 border-t border-slate-100">
              <button
                type="button"
                onClick={() => onNavigate('bantuan-profesional')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-[13px] font-bold transition-colors cursor-pointer ${
                  currentRoute === 'bantuan-profesional'
                    ? 'bg-[#F3CFC4] text-[#182334]'
                    : 'bg-[#F9DFD7]/80 hover:bg-[#F9DFD7] text-[#182334]'
                }`}
              >
                <HeartHandshake className="w-[18px] h-[18px] shrink-0" />
                <span className="text-left">Bantuan Profesional</span>
              </button>
              <p className="mt-2.5 px-1 text-[11px] leading-relaxed text-[#64748B]">
                Buddy adalah teman sebaya, bukan psikolog atau layanan krisis.
              </p>
            </div>
          </div>

          {/* User Profile Mini Footer */}
          <button
            type="button"
            onClick={() => onNavigate('profil')}
            className="mt-6 flex items-center gap-3 p-3 rounded-2xl bg-[#F6F8FC] hover:bg-[#EDF1FB] transition-colors text-left cursor-pointer"
          >
            <BuddyAvatar variant={user.mascot} size="sm" />
            <div className="min-w-0">
              <div className="text-[13px] font-bold text-[#182334] truncate">
                {user.name}
              </div>
              <div className="text-[11px] text-[#64748B] truncate">
                {user.email}
              </div>
            </div>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main
        className={`flex-1 min-w-0 w-full ${
          !isImmersive ? 'pb-28 md:pb-6' : 'pb-6'
        }`}
      >
        <div
          className={`mx-auto w-full ${
            isImmersive ? 'max-w-[540px] lg:max-w-[640px]' : 'max-w-[540px] md:max-w-none'
          }`}
        >
          {children}
        </div>
      </main>

      {/* Mobile Floating Pill Bottom Navigation Bar */}
      {!isImmersive && (
        <div className="md:hidden fixed bottom-4 inset-x-0 z-40 px-4 pointer-events-none">
          <nav
            aria-label="Navigasi bawah"
            className="max-w-[400px] mx-auto bg-white/95 backdrop-blur-md rounded-full p-1.5 shadow-[0_10px_32px_rgba(24,35,52,0.10)] grid grid-cols-4 gap-1 pointer-events-auto"
          >
            {PRIMARY_TABS.map((tab) => {
              const Icon = tab.icon;
              const active = currentRoute === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => onNavigate(tab.id)}
                  className={`relative flex flex-col items-center justify-center py-2 px-1 rounded-full transition-all cursor-pointer min-h-[52px] ${
                    active
                      ? 'bg-[#93A8E6] text-[#182334]'
                      : 'text-[#475569] hover:text-[#182334]'
                  }`}
                >
                  <Icon className="w-[19px] h-[19px] mb-0.5" />
                  <span className="text-[11px] font-semibold tracking-tight leading-none whitespace-nowrap">
                    {tab.label}
                  </span>
                </button>
              );
            })}
          </nav>
        </div>
      )}
    </div>
  );
};
