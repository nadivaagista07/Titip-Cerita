import { useCallback, useEffect, useState } from 'react';
import { Toast } from './components/common/Toast';
import { AppShell } from './components/layout/AppShell';
import { PrivacySheet } from './components/modals/PrivacySheet';
import { ReviewSheet } from './components/modals/ReviewSheet';
import { SessionDetailSheet } from './components/modals/SessionDetailSheet';
import {
  BUDDY_AUTO_REPLIES,
  INITIAL_COMMUNITY_POSTS,
  INITIAL_SESSIONS,
  INITIAL_USER,
} from './data/mockData';
import { usePersistentState } from './hooks/usePersistentState';
import { BantuanProfesionalPage } from './pages/BantuanProfesionalPage';
import { ChatRoomPage } from './pages/ChatRoomPage';
import { HomePage } from './pages/HomePage';
import { KomunitasPage } from './pages/KomunitasPage';
import { PaymentBankPage } from './pages/PaymentBankPage';
import { PaymentMethodPage } from './pages/PaymentMethodPage';
import { PaymentQrisPage } from './pages/PaymentQrisPage';
import { PaymentSuccessPage } from './pages/PaymentSuccessPage';
import { ProfilPage } from './pages/ProfilPage';
import { SesiSayaPage } from './pages/SesiSayaPage';
import { StudyRoomPage } from './pages/StudyRoomPage';
import {
  AppRoute,
  BookingDraft,
  Buddy,
  CommunityPost,
  SesiTab,
  SessionItem,
  SessionReview,
  SessionType,
  UserProfile,
} from './types';

const DEFAULT_DRAFT: BookingDraft = {
  buddyId: 'nara',
  buddyName: 'Nara',
  buddyVerified: true,
  buddyMascot: 'periwinkle',
  type: 'Chat',
  durationLabel: '30 menit',
  durationMinutes: 30,
  dateLabel: '20 Okt 2026',
  timeLabel: '19.00–19.30 WIB',
  price: 15000,
  paymentMethod: 'ewallet',
  ewalletProvider: 'GoPay',
};

export function App() {
  const [route, setRoute] = useState<AppRoute>('sesi-saya');
  const [prevRoute, setPrevRoute] = useState<AppRoute>('sesi-saya');
  const [sesiTab, setSesiTab] = useState<SesiTab>('upcoming');

  const [user, setUser] = usePersistentState<UserProfile>(
    'titipcerita_user_v1',
    INITIAL_USER
  );
  const [sessions, setSessions] = usePersistentState<SessionItem[]>(
    'titipcerita_sessions_v1',
    INITIAL_SESSIONS
  );
  const [posts, setPosts] = usePersistentState<CommunityPost[]>(
    'titipcerita_posts_v1',
    INITIAL_COMMUNITY_POSTS
  );

  const [bookingDraft, setBookingDraft] = useState<BookingDraft>(DEFAULT_DRAFT);
  const [activeRoomSessionId, setActiveRoomSessionId] = useState<string>('ses-live-1');
  const [latestPaidSessionId, setLatestPaidSessionId] = useState<string>('ses-live-1');
  const [detailSessionId, setDetailSessionId] = useState<string | null>(null);
  const [reviewSessionId, setReviewSessionId] = useState<string | null>(null);
  const [privacySheetOpen, setPrivacySheetOpen] = useState(false);
  const [typingSessionId, setTypingSessionId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
  }, []);

  useEffect(() => {
    if (!toastMessage) return;
    const t = window.setTimeout(() => setToastMessage(null), 2800);
    return () => window.clearTimeout(t);
  }, [toastMessage]);

  // Live countdown for ongoing sessions
  useEffect(() => {
    const id = window.setInterval(() => {
      setSessions((prev) => {
        const hasTickable = prev.some(
          (s) => s.status === 'ongoing' && s.remainingSeconds > 0
        );
        if (!hasTickable) return prev;
        return prev.map((s) =>
          s.status === 'ongoing' && s.remainingSeconds > 0
            ? { ...s, remainingSeconds: s.remainingSeconds - 1 }
            : s
        );
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [setSessions]);

  const navigateTo = useCallback(
    (next: AppRoute) => {
      setPrevRoute(route);
      setRoute(next);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    },
    [route]
  );

  const ongoingSessions = sessions.filter((s) => s.status === 'ongoing');
  const primaryOngoing = ongoingSessions[0];
  const studyPreviewSession =
    sessions.find((s) => s.type === 'Study' && s.status !== 'completed') ??
    sessions.find((s) => s.type === 'Study');

  const activeRoomSession =
    sessions.find((s) => s.id === activeRoomSessionId) ??
    primaryOngoing ??
    sessions[0];

  const latestPaidSession =
    sessions.find((s) => s.id === latestPaidSessionId) ?? sessions[0];

  const detailSession = detailSessionId
    ? sessions.find((s) => s.id === detailSessionId) ?? null
    : null;

  const reviewSession = reviewSessionId
    ? sessions.find((s) => s.id === reviewSessionId) ?? null
    : null;

  const handleStartBooking = (
    buddy: Buddy,
    type: SessionType,
    timeLabel: string
  ) => {
    const isChat = type === 'Chat';
    setBookingDraft({
      buddyId: buddy.id,
      buddyName: buddy.name,
      buddyVerified: buddy.verified,
      buddyMascot: buddy.mascot,
      type,
      durationLabel: isChat ? '30 menit' : '1 jam',
      durationMinutes: isChat ? 30 : 60,
      dateLabel: '20 Okt 2026',
      timeLabel,
      price: isChat ? buddy.chatPrice30 : buddy.studyPrice60,
      paymentMethod: 'ewallet',
      ewalletProvider: 'GoPay',
    });
    navigateTo('payment');
  };

  const handleBookAgain = (session: SessionItem) => {
    setBookingDraft({
      buddyId: session.buddyId,
      buddyName: session.buddyName,
      buddyVerified: session.buddyVerified,
      buddyMascot: session.buddyMascot,
      type: session.type,
      durationLabel: session.durationLabel,
      durationMinutes: session.durationMinutes,
      dateLabel: '20 Okt 2026',
      timeLabel: session.timeLabel,
      price: session.price,
      paymentMethod: 'ewallet',
      ewalletProvider: 'GoPay',
    });
    navigateTo('payment');
  };

  const handleProceedFromMethod = () => {
    if (bookingDraft.paymentMethod === 'bank') {
      navigateTo('payment-bank');
    } else if (bookingDraft.paymentMethod === 'qris') {
      navigateTo('payment-qris');
    } else {
      finalizePayment();
    }
  };

  const finalizePayment = () => {
    const newId = `ses-${Date.now()}`;
    const orderNum = String(Math.floor(10 + Math.random() * 89));
    const methodLabel =
      bookingDraft.paymentMethod === 'ewallet'
        ? bookingDraft.ewalletProvider
        : bookingDraft.paymentMethod === 'bank'
        ? 'BCA Virtual Account'
        : 'QRIS';

    const newSession: SessionItem = {
      id: newId,
      orderId: `TC201026${orderNum}`,
      buddyId: bookingDraft.buddyId,
      buddyName: bookingDraft.buddyName,
      buddyVerified: bookingDraft.buddyVerified,
      buddyMascot: bookingDraft.buddyMascot,
      type: bookingDraft.type,
      durationLabel: bookingDraft.durationLabel,
      durationMinutes: bookingDraft.durationMinutes,
      dateLabel: bookingDraft.dateLabel,
      timeLabel: bookingDraft.timeLabel,
      price: bookingDraft.price,
      status: 'upcoming',
      paid: true,
      paymentMethodLabel: methodLabel,
      remainingSeconds: bookingDraft.durationMinutes * 60,
      messages: [
        {
          id: `msg-${Date.now()}`,
          sender: 'buddy',
          text:
            bookingDraft.type === 'Study'
              ? `Hai ${user.name}, aku ${bookingDraft.buddyName}. Kita fokus 25 menit dulu, lalu istirahat 5 menit. Target kecilmu hari ini apa?`
              : `Hai ${user.name}, aku ${bookingDraft.buddyName}. Makasih sudah datang. Mau mulai dari kabarmu hari ini?`,
          time: '19.00',
        },
      ],
    };

    setSessions((prev) => [newSession, ...prev]);
    setLatestPaidSessionId(newId);
    navigateTo('payment-success');
  };

  const handleEnterRoom = (session: SessionItem) => {
    setDetailSessionId(null);
    if (session.status === 'upcoming') {
      setSessions((prev) =>
        prev.map((s) =>
          s.id === session.id ? { ...s, status: 'ongoing' } : s
        )
      );
    }
    setActiveRoomSessionId(session.id);
    navigateTo(session.type === 'Study' ? 'study-room' : 'chat-room');
  };

  const handleSendMessage = (sessionId: string, text: string) => {
    const now = new Date();
    const hh = String(now.getHours()).padStart(2, '0');
    const mm = String(now.getMinutes()).padStart(2, '0');
    const timeStr = `${hh}.${mm}`;

    const userMsgId = `msg-u-${Date.now()}`;
    setSessions((prev) =>
      prev.map((s) =>
        s.id === sessionId
          ? {
              ...s,
              messages: [
                ...s.messages,
                { id: userMsgId, sender: 'user', text, time: timeStr, read: true },
              ],
            }
          : s
      )
    );

    const targetSession = sessions.find((s) => s.id === sessionId);
    const buddyId = targetSession?.buddyId ?? 'nara';
    const pool = BUDDY_AUTO_REPLIES[buddyId] ?? BUDDY_AUTO_REPLIES.nara;
    const replyText = pool[Math.floor(Math.random() * pool.length)];

    setTypingSessionId(sessionId);
    window.setTimeout(() => {
      setTypingSessionId((curr) => (curr === sessionId ? null : curr));
      setSessions((prev) =>
        prev.map((s) =>
          s.id === sessionId
            ? {
                ...s,
                messages: [
                  ...s.messages,
                  {
                    id: `msg-b-${Date.now()}`,
                    sender: 'buddy',
                    text: replyText,
                    time: timeStr,
                  },
                ],
              }
            : s
        )
      );
    }, 1100);
  };

  const handleEndSession = (sessionId: string) => {
    setSessions((prev) =>
      prev.map((s) =>
        s.id === sessionId ? { ...s, status: 'completed', remainingSeconds: 0 } : s
      )
    );
    setReviewSessionId(sessionId);
    setSesiTab('completed');
    navigateTo('sesi-saya');
  };

  const handleSubmitReview = (sessionId: string, review: SessionReview) => {
    setSessions((prev) =>
      prev.map((s) =>
        s.id === sessionId ? { ...s, status: 'completed', review } : s
      )
    );
    setReviewSessionId(null);
    setSesiTab('completed');
    showToast('Terima kasih! Ulasanmu berhasil dikirim.');
  };

  const handleReschedule = (sessionId: string, newTimeLabel: string) => {
    setSessions((prev) =>
      prev.map((s) =>
        s.id === sessionId ? { ...s, timeLabel: newTimeLabel } : s
      )
    );
    setDetailSessionId(null);
    showToast(`Jadwal diperbarui ke ${newTimeLabel}.`);
  };

  const handleCancelSession = (sessionId: string) => {
    setSessions((prev) => prev.filter((s) => s.id !== sessionId));
    setDetailSessionId(null);
    showToast('Sesi terjadwal telah dibatalkan.');
  };

  const handleAddCommunityPost = (topic: string, content: string) => {
    const newPost: CommunityPost = {
      id: `post-${Date.now()}`,
      alias: user.anonymousByDefault ? 'BintangTenang' : user.name,
      mascot: user.mascot,
      topic,
      content,
      timeAgo: 'Baru saja',
      hugsCount: 1,
      huggedByMe: true,
    };
    setPosts((prev) => [newPost, ...prev]);
    showToast('Ceritamu sudah dibagikan ke ruang komunitas.');
  };

  const handleToggleHug = (postId: string) => {
    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId
          ? {
              ...p,
              huggedByMe: !p.huggedByMe,
              hugsCount: p.huggedByMe ? Math.max(0, p.hugsCount - 1) : p.hugsCount + 1,
            }
          : p
      )
    );
  };

  const handleResetDemoData = () => {
    setUser(INITIAL_USER);
    setSessions(INITIAL_SESSIONS);
    setPosts(INITIAL_COMMUNITY_POSTS);
    showToast('Data demo awal berhasil dipulihkan.');
  };

  return (
    <>
      <Toast message={toastMessage} />

      <AppShell
        currentRoute={route}
        onNavigate={(r) => navigateTo(r)}
        user={user}
        ongoingCount={ongoingSessions.length}
      >
        {route === 'home' && (
          <HomePage
            userName={user.name}
            ongoingSession={primaryOngoing}
            studySession={studyPreviewSession}
            onStartBooking={handleStartBooking}
            onEnterRoom={handleEnterRoom}
            onOpenBantuanProfesional={() => navigateTo('bantuan-profesional')}
          />
        )}

        {route === 'komunitas' && (
          <KomunitasPage
            posts={posts}
            user={user}
            onAddPost={handleAddCommunityPost}
            onToggleHug={handleToggleHug}
          />
        )}

        {route === 'sesi-saya' && (
          <SesiSayaPage
            activeTab={sesiTab}
            onChangeTab={setSesiTab}
            sessions={sessions}
            onOpenDetail={(s) => setDetailSessionId(s.id)}
            onEnterRoom={handleEnterRoom}
            onBookAgain={handleBookAgain}
            onOpenReview={(s) => setReviewSessionId(s.id)}
            onFindBuddy={() => navigateTo('home')}
            onShowToast={showToast}
          />
        )}

        {route === 'profil' && (
          <ProfilPage
            user={user}
            onUpdateUser={(patch) => setUser((prev) => ({ ...prev, ...patch }))}
            onOpenPrivacySheet={() => setPrivacySheetOpen(true)}
            onShowToast={showToast}
          />
        )}

        {route === 'payment' && (
          <PaymentMethodPage
            draft={bookingDraft}
            userName={user.name}
            onUpdateDraft={(patch) =>
              setBookingDraft((prev) => ({ ...prev, ...patch }))
            }
            onBack={() =>
              navigateTo(
                prevRoute === 'payment-bank' || prevRoute === 'payment-qris'
                  ? 'sesi-saya'
                  : prevRoute
              )
            }
            onProceed={handleProceedFromMethod}
            onShowToast={showToast}
          />
        )}

        {route === 'payment-bank' && (
          <PaymentBankPage
            draft={bookingDraft}
            onBack={() => navigateTo('payment')}
            onChangeMethod={() => navigateTo('payment')}
            onConfirmPayment={finalizePayment}
            onShowToast={showToast}
          />
        )}

        {route === 'payment-qris' && (
          <PaymentQrisPage
            draft={bookingDraft}
            onBack={() => navigateTo('payment')}
            onChangeMethod={() => navigateTo('payment')}
            onConfirmPayment={finalizePayment}
            onShowToast={showToast}
          />
        )}

        {route === 'payment-success' && (
          <PaymentSuccessPage
            session={latestPaidSession}
            onViewSessions={() => {
              setSesiTab('upcoming');
              navigateTo('sesi-saya');
            }}
            onBackHome={() => navigateTo('home')}
            onShowToast={showToast}
          />
        )}

        {route === 'chat-room' && activeRoomSession && (
          <ChatRoomPage
            session={activeRoomSession}
            isTyping={typingSessionId === activeRoomSession.id}
            onSendMessage={handleSendMessage}
            onEndSession={handleEndSession}
            onBack={() => {
              setSesiTab('ongoing');
              navigateTo('sesi-saya');
            }}
            onOpenBantuanProfesional={() => navigateTo('bantuan-profesional')}
            onShowToast={showToast}
          />
        )}

        {route === 'study-room' && activeRoomSession && (
          <StudyRoomPage
            session={activeRoomSession}
            isTyping={typingSessionId === activeRoomSession.id}
            onSendMessage={handleSendMessage}
            onEndSession={handleEndSession}
            onBack={() => {
              setSesiTab('ongoing');
              navigateTo('sesi-saya');
            }}
            onOpenBantuanProfesional={() => navigateTo('bantuan-profesional')}
            onShowToast={showToast}
          />
        )}

        {route === 'bantuan-profesional' && (
          <BantuanProfesionalPage
            onBack={() =>
              navigateTo(
                prevRoute === 'bantuan-profesional' ? 'sesi-saya' : prevRoute
              )
            }
            onShowToast={showToast}
          />
        )}
      </AppShell>

      {/* Modals & Bottom Sheets */}
      {detailSession && (
        <SessionDetailSheet
          session={detailSession}
          onStartSession={handleEnterRoom}
          onReschedule={handleReschedule}
          onCancelSession={handleCancelSession}
          onClose={() => setDetailSessionId(null)}
        />
      )}

      {reviewSession && (
        <ReviewSheet
          session={reviewSession}
          readOnly={Boolean(reviewSession.review)}
          onSubmit={handleSubmitReview}
          onClose={() => setReviewSessionId(null)}
        />
      )}

      {privacySheetOpen && (
        <PrivacySheet
          user={user}
          onToggleAnonymous={() => {
            const next = !user.anonymousByDefault;
            setUser((prev) => ({ ...prev, anonymousByDefault: next }));
            showToast(
              next
                ? 'Nama samaran otomatis diaktifkan.'
                : 'Nama samaran otomatis dinonaktifkan.'
            );
          }}
          onOpenBantuanProfesional={() => navigateTo('bantuan-profesional')}
          onResetDemoData={handleResetDemoData}
          onShowToast={showToast}
          onClose={() => setPrivacySheetOpen(false)}
        />
      )}
    </>
  );
}

export default App;
