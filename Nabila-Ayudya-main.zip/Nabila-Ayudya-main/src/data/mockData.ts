import { Buddy, CommunityPost, SessionItem, UserProfile } from '../types';

export const INITIAL_USER: UserProfile = {
  name: 'Alya',
  age: 21,
  birthDate: '2005-04-14',
  joinedLabel: 'Bergabung Oktober 2026',
  email: 'alya@email.com',
  mascot: 'periwinkle',
  interests: ['Musik', 'Kampus', 'Journaling'],
  notificationsEnabled: true,
  anonymousByDefault: true,
  blockedAccounts: [
    { id: 'blk-1', name: 'pengguna_anonim_84', blockedAt: '12 Okt 2026' },
  ],
};

export const BUDDIES: Buddy[] = [
  {
    id: 'nara',
    name: 'Nara',
    verified: true,
    mascot: 'periwinkle',
    role: 'Teman Cerita & Belajar',
    bio: 'Suka mendengarkan tanpa terburu-buru, menemani overthinking malam, atau jadi teman fokus baca & nugas.',
    rating: 4.9,
    totalSessions: 142,
    tags: ['Pendengar baik', 'Tidak menghakimi'],
    availableSlots: ['19.00–19.30 WIB', '20.00–20.30 WIB', '21.00–22.00 WIB'],
    chatPrice30: 15000,
    studyPrice60: 20000,
  },
  {
    id: 'dimas',
    name: 'Dimas',
    verified: true,
    mascot: 'mint',
    role: 'Teman Belajar Pomodoro',
    bio: 'Mahasiswa tingkat akhir yang biasa menemani sesi Pomodoro, menyusun target belajar kecil, dan berbagi ketenangan.',
    rating: 4.8,
    totalSessions: 98,
    tags: ['Teman fokus', 'Sabar'],
    availableSlots: ['20.00–21.00 WIB', '21.00–22.00 WIB', '16.00–16.30 WIB'],
    chatPrice30: 15000,
    studyPrice60: 20000,
  },
  {
    id: 'klara',
    name: 'Klara',
    verified: true,
    mascot: 'mint',
    role: 'Teman Cerita Sebaya',
    bio: 'Pendengar hangat untuk cerita seputar kampus, transisi dewasa muda, dan hari-hari yang terasa penuh.',
    rating: 4.9,
    totalSessions: 116,
    tags: ['Hangat', 'Empatik'],
    availableSlots: ['18.30–19.00 WIB', '19.30–20.00 WIB', '20.30–21.30 WIB'],
    chatPrice30: 15000,
    studyPrice60: 20000,
  },
];

export const INITIAL_SESSIONS: SessionItem[] = [
  {
    id: 'ses-up-1',
    orderId: 'TC20102602',
    buddyId: 'nara',
    buddyName: 'Nara',
    buddyVerified: true,
    buddyMascot: 'periwinkle',
    type: 'Chat',
    durationLabel: '30 menit',
    durationMinutes: 30,
    dateLabel: '20 Okt 2026',
    timeLabel: '19.00–19.30 WIB',
    price: 15000,
    status: 'upcoming',
    paid: true,
    paymentMethodLabel: 'GoPay',
    remainingSeconds: 30 * 60,
    messages: [
      {
        id: 'm-up-1',
        sender: 'buddy',
        text: 'Hai Alya, aku Nara. Makasih sudah datang. Mau mulai dari kabarmu hari ini?',
        time: '19.00',
      },
    ],
  },
  {
    id: 'ses-up-2',
    orderId: 'TC21102603',
    buddyId: 'dimas',
    buddyName: 'Dimas',
    buddyVerified: true,
    buddyMascot: 'mint',
    type: 'Study',
    durationLabel: '1 jam',
    durationMinutes: 60,
    dateLabel: '21 Okt 2026',
    timeLabel: '20.00–21.00 WIB',
    price: 20000,
    status: 'upcoming',
    paid: true,
    paymentMethodLabel: 'QRIS',
    remainingSeconds: 52 * 60 + 10,
    messages: [
      {
        id: 'm-study-1',
        sender: 'buddy',
        text: 'Kita fokus 25 menit dulu, lalu istirahat 5 menit. Target kecilmu malam ini apa?',
        time: '19.00',
      },
      {
        id: 'm-study-2',
        sender: 'user',
        text: 'Baca satu bab dan bikin rangkuman. Yuk mulai!',
        time: '19.01',
        read: true,
      },
    ],
  },
  {
    id: 'ses-live-1',
    orderId: 'TC20102601',
    buddyId: 'nara',
    buddyName: 'Nara',
    buddyVerified: true,
    buddyMascot: 'periwinkle',
    type: 'Chat',
    durationLabel: '30 menit',
    durationMinutes: 30,
    dateLabel: '20 Okt 2026',
    timeLabel: '19.00–19.30 WIB',
    price: 15000,
    status: 'ongoing',
    paid: true,
    paymentMethodLabel: 'GoPay',
    remainingSeconds: 24 * 60 + 18,
    messages: [
      {
        id: 'm-live-1',
        sender: 'buddy',
        text: 'Hai Alya, aku Nara. Makasih sudah datang. Mau mulai dari kabarmu hari ini?',
        time: '19.00',
      },
      {
        id: 'm-live-2',
        sender: 'user',
        text: 'Hari ini rasanya penuh banget. Banyak tugas, tapi bingung mau mulai dari mana.',
        time: '19.01',
        read: true,
      },
      {
        id: 'm-live-3',
        sender: 'buddy',
        text: 'Kedengarannya melelahkan. Aku di sini, kok. Bagian mana yang paling ingin kamu ceritakan dulu?',
        time: '19.04',
      },
    ],
  },
  {
    id: 'ses-study-demo',
    orderId: 'TC20102609',
    buddyId: 'nara',
    buddyName: 'Nara',
    buddyVerified: true,
    buddyMascot: 'periwinkle',
    type: 'Study',
    durationLabel: '1 jam',
    durationMinutes: 60,
    dateLabel: '20 Okt 2026',
    timeLabel: '20.00–21.00 WIB',
    price: 20000,
    status: 'upcoming',
    paid: true,
    paymentMethodLabel: 'BCA Virtual Account',
    remainingSeconds: 52 * 60 + 10,
    messages: [
      {
        id: 'm-nara-st-1',
        sender: 'buddy',
        text: 'Kita fokus 25 menit dulu, lalu istirahat 5 menit. Target kecilmu malam ini apa?',
        time: '19.00',
      },
      {
        id: 'm-nara-st-2',
        sender: 'user',
        text: 'Baca satu bab dan bikin rangkuman. Yuk mulai!',
        time: '19.01',
        read: true,
      },
    ],
  },
  {
    id: 'ses-done-1',
    orderId: 'TC20102600',
    buddyId: 'nara',
    buddyName: 'Nara',
    buddyVerified: true,
    buddyMascot: 'periwinkle',
    type: 'Chat',
    durationLabel: '30 menit',
    durationMinutes: 30,
    dateLabel: '20 Okt 2026',
    timeLabel: '19.00–19.30 WIB',
    price: 15000,
    status: 'completed',
    paid: true,
    paymentMethodLabel: 'GoPay',
    remainingSeconds: 0,
    messages: [
      {
        id: 'm-done-1',
        sender: 'buddy',
        text: 'Hai Alya, terima kasih sudah berbagi hari ini. Semoga malammu terasa lebih ringan.',
        time: '19.29',
      },
    ],
    review: {
      rating: 5,
      tags: ['Pendengar baik', 'Tidak menghakimi'],
      comment: 'Makasih sudah mendengarkan tanpa buru-buru. Aku jadi lebih lega dan tahu mau mulai dari mana.',
      anonymous: true,
      submittedAt: '20 Okt 2026',
    },
  },
];

export const INITIAL_COMMUNITY_POSTS: CommunityPost[] = [
  {
    id: 'post-1',
    alias: 'AwanPagi',
    mascot: 'periwinkle',
    topic: 'Kampus',
    content: 'Hari ini berhasil nyelesaiin satu bab skripsi setelah seminggu menunda. Ternyata cukup mulai 15 menit dulu aja, nggak harus langsung beres semua.',
    timeAgo: '18 menit lalu',
    hugsCount: 14,
    huggedByMe: false,
  },
  {
    id: 'post-2',
    alias: 'TehHangat',
    mascot: 'mint',
    topic: 'Journaling',
    content: 'Lagi belajar bilang ke diri sendiri bahwa capek itu bukan berarti malas. Istirahat sebentar juga bagian dari jalan terus.',
    timeAgo: '1 jam lalu',
    hugsCount: 23,
    huggedByMe: true,
  },
  {
    id: 'post-3',
    alias: 'LangitSenja',
    mascot: 'periwinkle',
    topic: 'Musik',
    content: 'Nyetel playlist akustik pelan sambil beresin meja belajar malam ini. Semoga siapa pun yang lagi ngerasa berat hari ini bisa tarik napas pelan.',
    timeAgo: '3 jam lalu',
    hugsCount: 19,
    huggedByMe: false,
  },
];

export const BUDDY_AUTO_REPLIES: Record<string, string[]> = {
  nara: [
    'Aku dengerin kok. Nggak apa-apa kalau rasanya masih berantakan, kita urai pelan-pelan satu per satu, ya.',
    'Wajar banget merasa kewalahan kalau semuanya datang bersamaan. Kalau ambil satu hal paling ringan dulu, kira-kira apa?',
    'Terima kasih sudah mau cerita sejauh ini. Kamu nggak harus menyelesaikan semuanya malam ini.',
    'Tarik napas pelan dulu sebentar ya. Aku tetap di sini menemani.',
  ],
  dimas: [
    'Bagus banget targetnya! Fokus satu langkah kecil dulu ya, nanti pas timer istirahat kita cek lagi progresmu.',
    'Mantap, pelan-pelan aja. Kalau mulai terdistraksi, cukup kembali ke satu paragraf di depanmu.',
    'Semangat! 25 menit terasa lebih ringan kalau dijalani bareng.',
  ],
  klara: [
    'Ceritamu valid banget. Pelan-pelan ya, nggak perlu memaksa diri langsung baik-baik saja.',
    'Aku senang kamu menyempatkan waktu untuk cerita hari ini. Apa yang paling bikin hatimu lega kalau diceritakan?',
  ],
};

export const PROFESSIONAL_DIRECTORY = [
  {
    id: 'dir-1',
    name: 'Puskesmas Kecamatan Menteng — Layanan Kesehatan Jiwa',
    type: 'Puskesmas',
    area: 'Jakarta Pusat',
    schedule: 'Senin–Jumat · 08.00–15.00 WIB',
    note: 'Tersedia layanan konseling psikolog klinis & rujukan BPJS Kesehatan.',
  },
  {
    id: 'dir-2',
    name: 'HIMPSI — Direktori Psikolog Berizin (SIPP)',
    type: 'Direktori Resmi',
    area: 'Seluruh Indonesia (Online & Tatap Muka)',
    schedule: 'Cek jadwal langsung di laman resmi',
    note: 'Verifikasi nomor izin praktik psikolog (SIPP) dan pilih bidang layanan sesuai kebutuhan.',
  },
  {
    id: 'dir-3',
    name: 'RSUD / Poliklinik Jiwa Terdekat',
    type: 'Rumah Sakit',
    area: 'Layanan Regional',
    schedule: 'Poliklinik Senin–Sabtu · IGD 24 Jam',
    note: 'Untuk kondisi darurat medis atau dukungan psikiatri/psikologi berkelanjutan.',
  },
];

export function formatRupiah(amount: number): string {
  return `Rp${amount.toLocaleString('id-ID')}`;
}

export function formatTimer(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}
