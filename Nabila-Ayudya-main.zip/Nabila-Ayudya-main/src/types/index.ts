export type MascotVariant = 'periwinkle' | 'mint';

export type SessionType = 'Chat' | 'Study';

export type SessionStatus = 'upcoming' | 'ongoing' | 'completed';

export type PaymentMethodId = 'ewallet' | 'bank' | 'qris';

export type EwalletProvider = 'GoPay' | 'OVO' | 'DANA';

export type AppRoute =
  | 'home'
  | 'komunitas'
  | 'sesi-saya'
  | 'profil'
  | 'payment'
  | 'payment-bank'
  | 'payment-qris'
  | 'payment-success'
  | 'chat-room'
  | 'study-room'
  | 'bantuan-profesional';

export type SesiTab = 'upcoming' | 'ongoing' | 'completed';

export interface Buddy {
  id: string;
  name: string;
  verified: boolean;
  mascot: MascotVariant;
  role: string;
  bio: string;
  rating: number;
  totalSessions: number;
  tags: string[];
  availableSlots: string[];
  chatPrice30: number;
  studyPrice60: number;
}

export interface ChatMessage {
  id: string;
  sender: 'buddy' | 'user';
  text: string;
  time: string;
  read?: boolean;
}

export interface SessionReview {
  rating: number;
  tags: string[];
  comment: string;
  anonymous: boolean;
  submittedAt: string;
}

export interface SessionItem {
  id: string;
  orderId: string;
  buddyId: string;
  buddyName: string;
  buddyVerified: boolean;
  buddyMascot: MascotVariant;
  type: SessionType;
  durationLabel: string;
  durationMinutes: number;
  dateLabel: string;
  timeLabel: string;
  price: number;
  status: SessionStatus;
  paid: boolean;
  paymentMethodLabel: string;
  remainingSeconds: number;
  messages: ChatMessage[];
  review?: SessionReview;
}

export interface BookingDraft {
  buddyId: string;
  buddyName: string;
  buddyVerified: boolean;
  buddyMascot: MascotVariant;
  type: SessionType;
  durationLabel: string;
  durationMinutes: number;
  dateLabel: string;
  timeLabel: string;
  price: number;
  paymentMethod: PaymentMethodId;
  ewalletProvider: EwalletProvider;
}

export interface UserProfile {
  name: string;
  age: number;
  birthDate: string;
  joinedLabel: string;
  email: string;
  mascot: MascotVariant;
  interests: string[];
  notificationsEnabled: boolean;
  anonymousByDefault: boolean;
  blockedAccounts: { id: string; name: string; blockedAt: string }[];
}

export interface CommunityPost {
  id: string;
  alias: string;
  mascot: MascotVariant;
  topic: string;
  content: string;
  timeAgo: string;
  hugsCount: number;
  huggedByMe: boolean;
}
