import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  ArrowUp,
  ArrowUpRight,
  Clock,
  Flag,
  HeartHandshake,
  Lock,
  Plus,
  X,
} from 'lucide-react';
import { BuddyAvatar } from '../components/assets/Mascots';
import { formatTimer } from '../data/mockData';
import { SessionItem } from '../types';

interface ChatRoomPageProps {
  session: SessionItem;
  isTyping: boolean;
  onSendMessage: (sessionId: string, text: string) => void;
  onEndSession: (sessionId: string) => void;
  onBack: () => void;
  onOpenBantuanProfesional: () => void;
  onShowToast: (msg: string) => void;
}

const QUICK_PROMPTS = [
  'Hari ini rasanya cukup berat, boleh aku cerita pelan-pelan?',
  'Banyak hal di kepalaku, bingung mulai dari mana.',
  'Aku cuma butuh ditemani sebentar tanpa harus kasih solusi.',
];

export const ChatRoomPage: React.FC<ChatRoomPageProps> = ({
  session,
  isTyping,
  onSendMessage,
  onEndSession,
  onBack,
  onOpenBantuanProfesional,
  onShowToast,
}) => {
  const [input, setInput] = useState('');
  const [showPrompts, setShowPrompts] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [showEndConfirm, setShowEndConfirm] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [session.messages.length, isTyping]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed) return;
    onSendMessage(session.id, trimmed);
    setInput('');
    setShowPrompts(false);
  };

  return (
    <div className="px-4 pt-3 pb-6 md:px-0 flex flex-col min-h-[calc(100dvh-1rem)] md:min-h-[calc(100dvh-3rem)]">
      {/* Header */}
      <header className="flex items-center justify-between py-2">
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={onBack}
            aria-label="Kembali"
            className="w-9 h-9 rounded-full hover:bg-white/70 flex items-center justify-center text-[#182334] cursor-pointer shrink-0"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <BuddyAvatar variant={session.buddyMascot} size="md" />
          <div className="min-w-0">
            <div className="text-[17px] font-extrabold text-[#182334] leading-tight truncate">
              {session.buddyName} {session.buddyVerified ? '✓' : ''}
            </div>
            <div className="text-[12px] text-[#526071] truncate">
              {session.type} · {session.durationLabel} · Terhubung
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setShowReportModal(true)}
          aria-label="Laporkan atau keamanan sesi"
          className="w-10 h-10 rounded-full hover:bg-white/70 flex items-center justify-center text-[#182334] cursor-pointer shrink-0"
        >
          <Flag className="w-5 h-5" strokeWidth={1.7} />
        </button>
      </header>

      {/* Live Timer Pill */}
      <div className="mt-2 bg-white rounded-full px-4 py-2.5 flex items-center justify-between shadow-[0_3px_14px_rgba(24,35,52,0.04)]">
        <div className="flex items-center gap-2 text-[13px] font-semibold text-[#182334] tabular-nums">
          <Clock className="w-4 h-4 text-[#334155]" />
          <span>Sisa waktu {formatTimer(session.remainingSeconds)}</span>
        </div>
        <button
          type="button"
          onClick={() => setShowEndConfirm(true)}
          className="text-[13px] font-bold text-[#182334] hover:text-rose-700 transition-colors cursor-pointer"
        >
          Akhiri sesi
        </button>
      </div>

      {/* Privacy Notice */}
      <div className="flex items-center justify-center gap-1.5 text-[11.5px] text-[#475569] mt-3">
        <Lock className="w-3.5 h-3.5 text-[#526071]" />
        <span>Jaga privasi. Tidak perlu berbagi kontak pribadi.</span>
      </div>

      {/* Date Divider */}
      <div className="text-center text-[11.5px] text-[#526071] mt-3 mb-4">
        {session.dateLabel.replace('Okt', 'Oktober')} · Hari ini
      </div>

      {/* Messages Feed */}
      <div className="flex-1 space-y-4 overflow-y-auto pb-4">
        {session.messages.map((msg) =>
          msg.sender === 'buddy' ? (
            <div key={msg.id} className="flex flex-col items-start">
              <div className="bg-white rounded-[22px] rounded-tl-md px-4 py-3.5 max-w-[85%] shadow-[0_2px_12px_rgba(24,35,52,0.03)] text-[14px] leading-relaxed text-[#182334]">
                {msg.text}
              </div>
              <span className="text-[11px] text-[#64748B] mt-1.5 ml-1 tabular-nums">
                {msg.time}
              </span>
            </div>
          ) : (
            <div key={msg.id} className="flex flex-col items-end">
              <div className="bg-[#C8D4F5] rounded-[22px] rounded-tr-md px-4 py-3.5 max-w-[85%] text-[14px] leading-relaxed text-[#182334]">
                {msg.text}
              </div>
              <span className="text-[11px] text-[#64748B] mt-1.5 mr-1 tabular-nums">
                {msg.time} · {msg.read ? 'Dibaca' : 'Terkirim'}
              </span>
            </div>
          )
        )}

        {isTyping && (
          <div className="flex items-start">
            <div className="bg-white rounded-full px-4 py-2.5 inline-flex items-center gap-2.5 shadow-[0_2px_10px_rgba(24,35,52,0.04)]">
              <span className="flex items-center gap-1" aria-hidden="true">
                <span className="w-1.5 h-1.5 rounded-full bg-[#94A3B8] animate-bounce" />
                <span className="w-1.5 h-1.5 rounded-full bg-[#64748B] animate-bounce [animation-delay:120ms]" />
                <span className="w-1.5 h-1.5 rounded-full bg-[#334155] animate-bounce [animation-delay:240ms]" />
              </span>
              <span className="text-[12px] text-[#475569] font-medium">
                {session.buddyName} mengetik
              </span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts Tray */}
      {showPrompts && (
        <div className="mb-2.5 flex flex-wrap gap-1.5">
          {QUICK_PROMPTS.map((prompt) => (
            <button
              key={prompt}
              type="button"
              onClick={() => {
                onSendMessage(session.id, prompt);
                setShowPrompts(false);
              }}
              className="px-3.5 py-2 rounded-2xl bg-white/95 hover:bg-white text-[12px] font-medium text-[#182334] shadow-xs text-left cursor-pointer"
            >
              {prompt}
            </button>
          ))}
        </div>
      )}

      {/* Composer & Safety Footer */}
      <div className="space-y-3 pt-2">
        <form
          onSubmit={handleSubmit}
          className="bg-white rounded-full p-1.5 pl-2.5 flex items-center gap-2 shadow-[0_4px_20px_rgba(24,35,52,0.05)]"
        >
          <button
            type="button"
            onClick={() => setShowPrompts((prev) => !prev)}
            aria-label="Pilih kalimat pembuka"
            className="w-9 h-9 rounded-full hover:bg-slate-100 flex items-center justify-center text-[#334155] cursor-pointer shrink-0"
          >
            <Plus className="w-5 h-5" />
          </button>

          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Tulis ceritamu di sini..."
            className="flex-1 bg-transparent text-[14px] text-[#182334] placeholder:text-[#94A3B8] focus:outline-none min-w-0"
          />

          <button
            type="submit"
            aria-label="Kirim pesan"
            className="w-10 h-10 rounded-full bg-[#93A8E6] hover:bg-[#8298DD] flex items-center justify-center text-[#182334] transition-colors cursor-pointer shrink-0"
          >
            <ArrowUp className="w-5 h-5" strokeWidth={2} />
          </button>
        </form>

        {/* Butuh bantuan profesional? */}
        <button
          type="button"
          onClick={onOpenBantuanProfesional}
          className="w-full h-12 rounded-full bg-[#F7D7CE] hover:bg-[#F3C9BD] flex items-center justify-center gap-2.5 text-[14px] font-bold text-[#182334] transition-colors cursor-pointer"
        >
          <HeartHandshake className="w-[18px] h-[18px]" strokeWidth={1.8} />
          <span>Butuh bantuan profesional?</span>
          <ArrowUpRight className="w-4 h-4" />
        </button>

        <p className="text-center text-[11px] text-[#526071]">
          Buddy bukan psikolog atau layanan krisis.
        </p>
      </div>

      {/* End Session Confirmation Modal */}
      {showEndConfirm && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#182334]/30 backdrop-blur-[2px] px-5"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-[380px] bg-white rounded-[28px] p-6 shadow-2xl">
            <h3 className="text-[18px] font-extrabold text-[#182334]">
              Akhiri sesi sekarang?
            </h3>
            <p className="text-[13.5px] text-[#475569] mt-2 leading-relaxed">
              Kamu memegang kendali penuh atas sesimu. Setelah diakhiri, kamu bisa memberi ulasan singkat untuk {session.buddyName}.
            </p>
            <div className="mt-5 flex gap-2.5">
              <button
                type="button"
                onClick={() => setShowEndConfirm(false)}
                className="flex-1 h-11 rounded-full border border-slate-200 text-[13.5px] font-bold text-[#475569] cursor-pointer"
              >
                Lanjut ngobrol
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowEndConfirm(false);
                  onEndSession(session.id);
                }}
                className="flex-1 h-11 rounded-full tc-btn-primary text-[13.5px] cursor-pointer"
              >
                Ya, akhiri sesi
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Safety / Report Modal */}
      {showReportModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#182334]/30 backdrop-blur-[2px] px-5"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-[380px] bg-white rounded-[28px] p-6 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-[17px] font-extrabold text-[#182334]">
                Keamanan &amp; Laporan
              </h3>
              <button
                type="button"
                onClick={() => setShowReportModal(false)}
                aria-label="Tutup"
                className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-[#526071] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-[13px] text-[#475569] mt-2 leading-relaxed">
              Merasa tidak nyaman selama sesi? Kamu bisa menghentikan sesi kapan saja atau mengirim laporan ke tim moderasi TitipCerita.
            </p>
            <div className="mt-4 space-y-2">
              <button
                type="button"
                onClick={() => {
                  setShowReportModal(false);
                  onShowToast('Laporan dikirim secara rahasia ke tim keamanan.');
                }}
                className="w-full h-11 rounded-full bg-[#F7E3DD] hover:bg-[#F3CFC4] text-[13.5px] font-bold text-[#182334] cursor-pointer"
              >
                Laporkan perilaku tidak nyaman
              </button>
              <button
                type="button"
                onClick={() => setShowReportModal(false)}
                className="w-full h-11 rounded-full border border-slate-200 text-[13.5px] font-semibold text-[#475569] cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
