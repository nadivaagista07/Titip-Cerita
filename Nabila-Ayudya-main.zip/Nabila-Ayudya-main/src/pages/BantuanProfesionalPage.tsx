import React, { useEffect, useState } from 'react';
import {
  ExternalLink,
  Heart,
  HeartHandshake,
  MapPin,
  MessageCircle,
  Phone,
  PhoneCall,
  Search,
  Wind,
  X,
} from 'lucide-react';
import { MintMascot } from '../components/assets/Mascots';
import { TopBar } from '../components/common/TopBar';
import { PROFESSIONAL_DIRECTORY } from '../data/mockData';

interface BantuanProfesionalPageProps {
  onBack: () => void;
  onShowToast: (msg: string) => void;
}

export const BantuanProfesionalPage: React.FC<BantuanProfesionalPageProps> = ({
  onBack,
  onShowToast,
}) => {
  const [directoryModal, setDirectoryModal] = useState<'psychologist' | 'puskesmas' | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [breathingActive, setBreathingActive] = useState(false);
  const [breathPhase, setBreathPhase] = useState<'Tarik napas' | 'Tahan sebentar' | 'Hembuskan pelan'>('Tarik napas');

  useEffect(() => {
    if (!breathingActive) return;
    let step = 0;
    const phases: ('Tarik napas' | 'Tahan sebentar' | 'Hembuskan pelan')[] = [
      'Tarik napas',
      'Tahan sebentar',
      'Hembuskan pelan',
    ];
    setBreathPhase(phases[0]);
    const interval = window.setInterval(() => {
      step = (step + 1) % 3;
      setBreathPhase(phases[step]);
    }, 4000);
    return () => window.clearInterval(interval);
  }, [breathingActive]);

  const filteredDirectory = PROFESSIONAL_DIRECTORY.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.area.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.note.toLowerCase().includes(searchQuery.toLowerCase());
    if (!matchesSearch) return false;
    if (directoryModal === 'psychologist') {
      return item.type === 'Direktori Resmi' || item.type === 'Puskesmas';
    }
    if (directoryModal === 'puskesmas') {
      return item.type === 'Puskesmas' || item.type === 'Rumah Sakit';
    }
    return true;
  });

  return (
    <div className="px-5 pt-2 pb-10 md:px-0">
      <TopBar
        title="Bantuan Profesional"
        onBack={onBack}
        onMore={() => onShowToast('Layanan darurat resmi Kementerian Kesehatan RI · 119 ext. 8')}
      />

      {/* Hero Section */}
      <div className="flex items-center justify-between gap-4 mt-2 mb-5">
        <div className="max-w-[65%]">
          <h2 className="text-[28px] md:text-[32px] font-extrabold text-[#182334] leading-[1.15] tracking-tight">
            Kamu layak mendapat dukungan.
          </h2>
          <p className="text-[13.5px] text-[#475569] mt-2 leading-relaxed">
            Tidak harus menghadapi semuanya sendirian.
          </p>
        </div>
        <div className="shrink-0">
          <MintMascot className="w-24 h-24 md:w-28 md:h-28" />
        </div>
      </div>

      {/* Disclaimer Callout */}
      <div className="bg-[#DFEFE8] rounded-[22px] p-4 flex items-start gap-3 mb-4">
        <Heart className="w-5 h-5 text-[#182334] shrink-0 mt-0.5" strokeWidth={1.8} />
        <div>
          <div className="text-[13.5px] font-bold text-[#182334] leading-snug">
            Pelan-pelan. Pilih bantuan yang kamu butuhkan.
          </div>
          <p className="text-[12.5px] text-[#334155] mt-1 leading-relaxed">
            Buddy adalah teman sebaya, bukan psikolog, tenaga kesehatan, atau layanan krisis.
          </p>
        </div>
      </div>

      {/* Main Healing119.id Card */}
      <section className="tc-card p-5 mb-4">
        <div className="flex items-start gap-3">
          <HeartHandshake className="w-6 h-6 text-[#182334] shrink-0 mt-0.5" strokeWidth={1.8} />
          <div>
            <h3 className="text-[19px] font-extrabold text-[#182334] leading-tight">
              Healing119.id
            </h3>
            <p className="text-[12px] text-[#526071] mt-0.5">
              Layanan Kementerian Kesehatan RI
            </p>
          </div>
        </div>

        <p className="text-[13.5px] text-[#334155] leading-relaxed mt-3.5">
          Dukungan psikologis awal untuk tekanan emosional, keputusasaan, atau pikiran untuk menyakiti diri. Kamu boleh mencari pertolongan sekarang.
        </p>

        <div className="mt-4 space-y-2.5">
          <a
            href="tel:119"
            onClick={() =>
              onShowToast('Menghubungi 119 ekstensi 8 (layanan telepon darurat).')
            }
            className="w-full h-12 rounded-full tc-btn-primary flex items-center justify-center gap-2.5 text-[14px]"
          >
            <Phone className="w-4 h-4" />
            <span>Telepon 119 ekstensi 8</span>
          </a>

          <a
            href="https://healing119.id"
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => onShowToast('Membuka portal informasi Healing119.id')}
            className="w-full h-12 rounded-full border border-slate-200 bg-white hover:bg-slate-50 flex items-center justify-center gap-2.5 text-[14px] font-bold text-[#182334] transition-colors"
          >
            <MessageCircle className="w-4 h-4 text-[#475569]" />
            <span>Akses WhatsApp via Healing119.id</span>
          </a>
        </div>

        <p className="text-[11.5px] leading-relaxed text-[#526071] mt-3.5">
          Kunjungi Healing119.id untuk akses WhatsApp dan informasi layanan. Ketersediaan mengikuti layanan; jika belum terhubung, coba kembali atau cari fasilitas kesehatan.
        </p>
      </section>

      {/* Immediate Medical Danger Peach Callout */}
      <div className="bg-[#F6E1DC] rounded-[22px] p-4 flex items-start gap-3 mb-4">
        <PhoneCall className="w-5 h-5 text-[#182334] shrink-0 mt-0.5" strokeWidth={1.8} />
        <div>
          <div className="text-[13.5px] font-bold text-[#182334]">
            Ada bahaya medis segera?
          </div>
          <p className="text-[12.5px] text-[#334155] mt-1 leading-relaxed">
            Telepon 119 atau datang ke IGD terdekat. Jika memungkinkan, minta orang yang kamu percaya untuk menemanimu.
          </p>
        </div>
      </div>

      {/* Ongoing Support Card */}
      <section className="tc-card p-5 mb-6">
        <h3 className="text-[18px] font-extrabold text-[#182334] leading-snug">
          Untuk dukungan berkelanjutan
        </h3>
        <p className="text-[13.5px] text-[#334155] leading-relaxed mt-2">
          Cari psikolog berizin atau tanyakan layanan kesehatan jiwa di Puskesmas/RS terdekat. Cek izin praktik, jadwal, dan biaya langsung dengan penyedia.
        </p>

        <div className="mt-4 space-y-2.5">
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              setDirectoryModal('psychologist');
            }}
            className="w-full h-12 rounded-full border border-slate-200 bg-white hover:bg-slate-50 flex items-center justify-center gap-2.5 text-[14px] font-bold text-[#182334] transition-colors cursor-pointer"
          >
            <Search className="w-4 h-4 text-[#475569]" />
            <span>Cari psikolog berizin</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              setDirectoryModal('puskesmas');
            }}
            className="w-full h-12 rounded-full border border-slate-200 bg-white hover:bg-slate-50 flex items-center justify-center gap-2.5 text-[14px] font-bold text-[#182334] transition-colors cursor-pointer"
          >
            <MapPin className="w-4 h-4 text-[#475569]" />
            <span>Cari Puskesmas / RS terdekat</span>
          </button>
        </div>
      </section>

      {/* Grounding Pause Section */}
      <section className="px-1 mb-6">
        <h3 className="text-[16px] font-extrabold text-[#182334]">
          Sambil menunggu, ambil satu jeda.
        </h3>
        <p className="text-[13px] text-[#475569] leading-relaxed mt-1.5">
          Cari tempat yang terasa aman, tarik napas perlahan, dan hubungi orang yang kamu percaya. Kamu tidak perlu menjelaskan semuanya sekaligus.
        </p>

        <div className="mt-3">
          <button
            type="button"
            onClick={() => setBreathingActive((prev) => !prev)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/80 hover:bg-white border border-slate-200/80 text-[12.5px] font-bold text-[#182334] transition-colors cursor-pointer"
          >
            <Wind className="w-4 h-4 text-[#526071]" />
            <span>
              {breathingActive ? `Panduan napas aktif: ${breathPhase}` : 'Panduan jeda napas perlahan'}
            </span>
          </button>
        </div>
      </section>

      {/* Source Citation */}
      <footer className="px-1 pt-2 border-t border-slate-200/60">
        <div className="text-[10.5px] font-bold tracking-wider uppercase text-[#526071]">
          SUMBER INFORMASI
        </div>
        <div className="text-[12px] text-[#334155] mt-1">
          Kemenkes RI · Kenali layanan Healing119.id
        </div>
        <a
          href="https://kesprimkom.kemkes.go.id/konten/127/151/0/cegah-bunuh-diri-dukung-kesehatan-jiwa-kenali-layanan-healing119-id"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-start gap-1 text-[11px] text-[#526071] hover:text-[#182334] underline break-all mt-1"
        >
          <span>
            https://kesprimkom.kemkes.go.id/konten/127/151/0/cegah-bunuh-diri-dukung-kesehatan-jiwa-kenali-layanan-healing119-id
          </span>
          <ExternalLink className="w-3 h-3 shrink-0 mt-0.5" />
        </a>
      </footer>

      {/* Directory Search Modal */}
      {directoryModal && (
        <div
          className="fixed inset-0 z-50 flex flex-col justify-end md:justify-center md:items-center bg-[#182334]/30 backdrop-blur-[2px]"
          role="dialog"
          aria-modal="true"
          onClick={(e) => {
            if (e.target === e.currentTarget) setDirectoryModal(null);
          }}
        >
          <div className="w-full max-w-[460px] mx-auto bg-white rounded-t-[32px] md:rounded-[32px] p-6 shadow-2xl max-h-[82dvh] flex flex-col">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-[18px] font-extrabold text-[#182334]">
                {directoryModal === 'psychologist'
                  ? 'Direktori Psikolog Berizin'
                  : 'Puskesmas & RS Kesehatan Jiwa'}
              </h3>
              <button
                type="button"
                onClick={() => setDirectoryModal(null)}
                aria-label="Tutup direktori"
                className="w-9 h-9 rounded-full hover:bg-slate-100 flex items-center justify-center text-[#526071] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="relative mb-4">
              <Search className="w-4 h-4 text-[#64748B] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari kota, nama layanan, atau jenis..."
                className="w-full h-11 pl-10 pr-4 rounded-full bg-[#F4F7FC] text-[13.5px] text-[#182334] placeholder:text-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#93A8E6]"
              />
            </div>

            <div className="space-y-3 overflow-y-auto pr-1">
              {filteredDirectory.map((item) => (
                <div
                  key={item.id}
                  className="p-4 rounded-2xl border border-slate-100 bg-[#FAFBFD]"
                >
                  <div className="text-[11px] font-bold text-[#526071]">
                    {item.type} · {item.area}
                  </div>
                  <div className="text-[14.5px] font-bold text-[#182334] mt-1">
                    {item.name}
                  </div>
                  <div className="text-[12px] text-[#526071] mt-1">
                    {item.schedule}
                  </div>
                  <p className="text-[12.5px] text-[#475569] mt-1.5 leading-relaxed">
                    {item.note}
                  </p>
                </div>
              ))}
              {filteredDirectory.length === 0 && (
                <p className="text-center text-[13px] text-[#64748B] py-6">
                  Tidak ada hasil untuk kata kunci tersebut.
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
