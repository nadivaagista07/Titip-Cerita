import React, { useEffect, useState } from 'react';
import { Clock, Copy, Landmark } from 'lucide-react';
import { BuddyAvatar } from '../components/assets/Mascots';
import { TopBar } from '../components/common/TopBar';
import { formatRupiah, formatTimer } from '../data/mockData';
import { BookingDraft } from '../types';

interface PaymentBankPageProps {
  draft: BookingDraft;
  onBack: () => void;
  onChangeMethod: () => void;
  onConfirmPayment: () => void;
  onShowToast: (msg: string) => void;
}

const VA_NUMBER = '8808 1234 5678 9012';

export const PaymentBankPage: React.FC<PaymentBankPageProps> = ({
  draft,
  onBack,
  onChangeMethod,
  onConfirmPayment,
  onShowToast,
}) => {
  const [secondsLeft, setSecondsLeft] = useState(14 * 60 + 59);

  useEffect(() => {
    const id = window.setInterval(() => {
      setSecondsLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => window.clearInterval(id);
  }, []);

  const handleCopyVa = async () => {
    try {
      await navigator.clipboard.writeText(VA_NUMBER.replace(/\s+/g, ''));
      onShowToast('Nomor Virtual Account disalin.');
    } catch {
      onShowToast('Nomor VA: 8808123456789012');
    }
  };

  return (
    <div className="px-5 pt-2 pb-10 md:px-0">
      <TopBar
        title="Transfer bank"
        onBack={onBack}
        onMore={() => onShowToast('Virtual Account aktif selama 15 menit.')}
      />

      {/* Waiting Payment Peach Banner */}
      <div className="bg-[#F7E3DD] rounded-[22px] p-4 flex items-start gap-3 mt-1 mb-4">
        <Clock className="w-5 h-5 text-[#182334] shrink-0 mt-0.5" strokeWidth={1.7} />
        <div>
          <div className="text-[13.5px] font-bold text-[#182334]">
            Menunggu pembayaran
          </div>
          <p className="text-[12.5px] text-[#334155] mt-1 leading-relaxed tabular-nums">
            Selesaikan dalam {formatTimer(secondsLeft)}. Sesi dikonfirmasi setelah pembayaran diterima.
          </p>
        </div>
      </div>

      {/* Session Card */}
      <div className="tc-card p-5 mb-4">
        <div className="flex items-center gap-3.5">
          <BuddyAvatar variant={draft.buddyMascot} size="lg" />
          <div>
            <div className="text-[16px] font-extrabold text-[#182334]">
              {draft.buddyName} · {draft.type}
            </div>
            <div className="text-[12.5px] text-[#526071] mt-0.5">
              {draft.dateLabel} · {draft.timeLabel}
            </div>
          </div>
        </div>
        <div className="flex items-center justify-between mt-4 pt-1">
          <span className="text-[13px] text-[#475569]">
            {draft.durationLabel}
          </span>
          <span className="text-[17px] font-extrabold text-[#182334] tabular-nums">
            {formatRupiah(draft.price)}
          </span>
        </div>
      </div>

      {/* BCA Virtual Account Card */}
      <div className="tc-card p-5 mb-5">
        <div className="flex items-center gap-2.5 mb-4">
          <Landmark className="w-5 h-5 text-[#182334]" strokeWidth={1.7} />
          <span className="text-[16px] font-extrabold text-[#182334]">
            BCA Virtual Account
          </span>
        </div>

        <div className="text-[10.5px] font-bold tracking-wider uppercase text-[#526071]">
          NOMOR VIRTUAL ACCOUNT · CONTOH
        </div>

        <div className="flex items-center justify-between gap-3 mt-1.5">
          <span className="text-[22px] font-extrabold text-[#182334] tracking-tight tabular-nums">
            {VA_NUMBER}
          </span>
          <button
            type="button"
            onClick={handleCopyVa}
            aria-label="Salin nomor Virtual Account"
            className="w-10 h-10 rounded-xl hover:bg-[#F3F6FC] flex items-center justify-center text-[#334155] transition-colors cursor-pointer shrink-0"
          >
            <Copy className="w-5 h-5" />
          </button>
        </div>

        <div className="text-[13px] text-[#475569] mt-2">
          Atas nama TitipCerita
        </div>

        <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-100">
          <span className="text-[13px] text-[#475569]">Jumlah transfer</span>
          <span className="text-[18px] font-extrabold text-[#182334] tabular-nums">
            {formatRupiah(draft.price)}
          </span>
        </div>
      </div>

      {/* How to Pay Instructions */}
      <div className="px-1 mb-6">
        <h3 className="text-[16px] font-extrabold text-[#182334] mb-3">
          Cara membayar
        </h3>
        <ol className="space-y-2.5 text-[13px] text-[#334155]">
          <li className="flex items-start gap-3">
            <span className="font-bold text-[#182334] shrink-0">1.</span>
            <span>Buka m-banking, pilih Transfer → Virtual Account.</span>
          </li>
          <li className="flex items-start gap-3">
            <span className="font-bold text-[#182334] shrink-0">2.</span>
            <span>Masukkan nomor di atas dan cek nama penerima.</span>
          </li>
          <li className="flex items-start gap-3">
            <span className="font-bold text-[#182334] shrink-0">3.</span>
            <span>Pastikan nominal {formatRupiah(draft.price)}, lalu konfirmasi.</span>
          </li>
        </ol>
      </div>

      {/* Actions */}
      <button
        type="button"
        onClick={onConfirmPayment}
        className="w-full h-13 rounded-full tc-btn-primary text-[15px] cursor-pointer"
      >
        Cek status pembayaran
      </button>

      <button
        type="button"
        onClick={onChangeMethod}
        className="mt-4 w-full py-2 text-[13px] font-semibold text-[#334155] hover:text-[#182334] cursor-pointer"
      >
        Ganti metode pembayaran
      </button>
    </div>
  );
};
