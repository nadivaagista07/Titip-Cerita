import React from 'react';
import {
  ArrowRight,
  Calendar,
  Clock,
  Heart,
  MessageSquare,
  MoreHorizontal,
  RotateCcw,
  Star,
} from 'lucide-react';
import { BuddyAvatar, DuoMascots } from '../components/assets/Mascots';
import { formatRupiah, formatTimer } from '../data/mockData';
import { SesiTab, SessionItem } from '../types';

interface SesiSayaPageProps {
  activeTab: SesiTab;
  onChangeTab: (tab: SesiTab) => void;
  sessions: SessionItem[];
  onOpenDetail: (session: SessionItem) => void;
  onEnterRoom: (session: SessionItem) => void;
  onBookAgain: (session: SessionItem) => void;
  onOpenReview: (session: SessionItem) => void;
  onFindBuddy: () => void;
  onShowToast: (msg: string) => void;
}

const TAB_COPY: Record<SesiTab, { title: string; subtitle: string }> = {
  upcoming: {
    title: 'Waktu untuk ditemani.',
    subtitle: 'Jadwal kecil untuk hari yang lebih ringan.',
  },
  ongoing: {
    title: 'Temanmu sudah di sini.',
    subtitle: 'Lanjutkan obrolan, sesuai ritmemu.',
  },
  completed: {
    title: 'Cerita yang sudah singgah.',
    subtitle: 'Terima kasih sudah memberi ruang untuk dirimu.',
  },
};

export const SesiSayaPage: React.FC<SesiSayaPageProps> = ({
  activeTab,
  onChangeTab,
  sessions,
  onOpenDetail,
  onEnterRoom,
  onBookAgain,
  onOpenReview,
  onFindBuddy,
  onShowToast,
}) => {
  const upcomingSessions = sessions.filter((s) => s.status === 'upcoming');
  const ongoingSessions = sessions.filter((s) => s.status === 'ongoing');
  const completedSessions = sessions.filter((s) => s.status === 'completed');

  const copy = TAB_COPY[activeTab];

  return (
    <div className="px-5 pt-3 pb-6 md:px-0">
      {/* Page Header */}
      <div className="flex items-center justify-between h-12">
        <h1 className="text-[18px] font-bold text-[#182334] tracking-tight">
          Sesi Saya
        </h1>
        <button
          type="button"
          onClick={() => onShowToast('Pengingat sesi aktif 15 menit sebelum jadwal.')}
          aria-label="Opsi Sesi Saya"
          className="w-10 h-10 rounded-full hover:bg-white/60 flex items-center justify-center text-[#182334] cursor-pointer"
        >
          <MoreHorizontal className="w-5 h-5" />
        </button>
      </div>

      {/* Headline & Subtitle */}
      <div className="mt-2 mb-5">
        <h2 className="text-[28px] md:text-[32px] font-extrabold text-[#182334] tracking-tight leading-[1.15]">
          {copy.title}
        </h2>
        <p className="text-[13.5px] text-[#475569] mt-1.5">
          {copy.subtitle}
        </p>
      </div>

      {/* Segmented Tab Control */}
      <div
        role="tablist"
        aria-label="Status sesi"
        className="bg-white rounded-full p-1.5 shadow-[0_3px_14px_rgba(24,35,52,0.04)] grid grid-cols-3 gap-1 mb-6 max-w-md"
      >
        {(
          [
            { id: 'upcoming', label: 'Akan Datang' },
            { id: 'ongoing', label: 'Berlangsung' },
            { id: 'completed', label: 'Selesai' },
          ] as { id: SesiTab; label: string }[]
        ).map((tab) => {
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => onChangeTab(tab.id)}
              className={`py-2.5 px-3 rounded-full text-[13px] transition-all cursor-pointer whitespace-nowrap ${
                active
                  ? 'bg-[#93A8E6] text-[#182334] font-bold shadow-xs'
                  : 'text-[#334155] font-medium hover:text-[#182334]'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Tab Content: Akan Datang */}
      {activeTab === 'upcoming' && (
        <div>
          {upcomingSessions.length === 0 ? (
            <div className="tc-card p-6 text-center">
              <p className="text-[14px] font-semibold text-[#182334]">
                Belum ada sesi terjadwal saat ini.
              </p>
              <button
                type="button"
                onClick={onFindBuddy}
                className="mt-4 px-6 h-11 rounded-full tc-btn-primary text-[13.5px] cursor-pointer"
              >
                Cari buddy di Home
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {upcomingSessions.map((session, idx) => (
                <article
                  key={session.id}
                  className="tc-card p-5 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3.5">
                        <BuddyAvatar variant={session.buddyMascot} size="lg" />
                        <div>
                          <div className="text-[17px] font-extrabold text-[#182334]">
                            {session.buddyName} {session.buddyVerified ? '✓' : ''}
                          </div>
                          <div className="text-[12.5px] text-[#526071] mt-0.5">
                            {session.type} · {session.durationLabel}
                          </div>
                        </div>
                      </div>
                      <span className="px-3 py-1 rounded-full bg-[#E3F1EA] text-[#182334] text-[11.5px] font-semibold shrink-0">
                        Terjadwal
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-[12.5px] text-[#475569] mt-4">
                      <Calendar className="w-4 h-4 text-[#64748B] shrink-0" />
                      <span>
                        {session.dateLabel} · {session.timeLabel}
                      </span>
                    </div>

                    <div className="flex items-center justify-between mt-3">
                      <span className="text-[16px] font-extrabold text-[#182334] tabular-nums">
                        {formatRupiah(session.price)}
                      </span>
                      <span className="text-[12px] text-[#526071]">
                        {session.paid ? 'Sudah dibayar' : 'Menunggu bayar'}
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => onOpenDetail(session)}
                    className={`mt-4 w-full h-12 rounded-full flex items-center justify-center gap-2 text-[13.5px] font-bold transition-colors cursor-pointer ${
                      idx === 0
                        ? 'tc-btn-primary'
                        : 'border border-slate-200 bg-white hover:bg-slate-50 text-[#182334]'
                    }`}
                  >
                    <ArrowRight className="w-4 h-4" />
                    <span>Lihat detail sesi</span>
                  </button>
                </article>
              ))}
            </div>
          )}

          <p className="text-center text-[12.5px] text-[#526071] mt-6">
            Kami mengingatkanmu sebelum sesi dimulai.
          </p>
        </div>
      )}

      {/* Tab Content: Berlangsung */}
      {activeTab === 'ongoing' && (
        <div className="space-y-5">
          {ongoingSessions.length === 0 ? (
            <div className="tc-card p-6 text-center">
              <p className="text-[14px] font-semibold text-[#182334]">
                Tidak ada sesi yang sedang berlangsung sekarang.
              </p>
              <button
                type="button"
                onClick={() => onChangeTab('upcoming')}
                className="mt-4 px-6 h-11 rounded-full tc-btn-primary text-[13.5px] cursor-pointer"
              >
                Lihat jadwal akan datang
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {ongoingSessions.map((session) => (
                <article key={session.id} className="tc-card p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3.5">
                      <BuddyAvatar variant={session.buddyMascot} size="lg" />
                      <div>
                        <div className="text-[17px] font-extrabold text-[#182334]">
                          {session.buddyName} {session.buddyVerified ? '✓' : ''}
                        </div>
                        <div className="text-[12.5px] text-[#526071] mt-0.5">
                          {session.type} · {session.durationLabel}
                        </div>
                      </div>
                    </div>
                    <span className="px-3.5 py-1 rounded-full bg-[#93A8E6] text-[#182334] text-[11.5px] font-bold shrink-0">
                      Berlangsung
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-[12.5px] text-[#475569] mt-4">
                    <Calendar className="w-4 h-4 text-[#64748B] shrink-0" />
                    <span>
                      {session.dateLabel} · {session.timeLabel}
                    </span>
                  </div>

                  <div className="flex items-center justify-between mt-3">
                    <span className="text-[16px] font-extrabold text-[#182334] tabular-nums">
                      {formatRupiah(session.price)}
                    </span>
                    <span className="text-[12px] text-[#526071]">
                      Sudah dibayar
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-[13px] font-semibold text-[#182334] mt-3.5 tabular-nums">
                    <Clock className="w-4 h-4 text-[#334155] shrink-0" />
                    <span>
                      Sisa waktu {formatTimer(session.remainingSeconds)} · {session.buddyName} menunggumu
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => onEnterRoom(session)}
                    className="mt-4 w-full h-12 rounded-full tc-btn-primary flex items-center justify-center gap-2 text-[13.5px] cursor-pointer"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>
                      {session.type === 'Study'
                        ? 'Kembali ke ruang belajar'
                        : 'Kembali ke ruang chat'}
                    </span>
                  </button>
                </article>
              ))}
            </div>
          )}

          {/* Control Assurance Mint Card */}
          <div className="bg-[#DFEFE8] rounded-[22px] p-4 flex items-start gap-3">
            <Heart className="w-5 h-5 text-[#182334] shrink-0 mt-0.5" strokeWidth={1.8} />
            <div>
              <div className="text-[13.5px] font-bold text-[#182334]">
                Kamu tetap memegang kendali
              </div>
              <p className="text-[12.5px] text-[#334155] mt-1 leading-relaxed">
                Kamu boleh mengakhiri sesi kapan pun. Tombol bantuan profesional selalu tersedia di ruang chat.
              </p>
            </div>
          </div>

          <div className="flex justify-center pt-2">
            <DuoMascots />
          </div>
        </div>
      )}

      {/* Tab Content: Selesai */}
      {activeTab === 'completed' && (
        <div className="space-y-5">
          {completedSessions.length === 0 ? (
            <div className="tc-card p-6 text-center">
              <p className="text-[14px] font-semibold text-[#182334]">
                Belum ada riwayat sesi yang selesai.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {completedSessions.map((session) => (
                <article key={session.id} className="tc-card p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3.5">
                      <BuddyAvatar variant={session.buddyMascot} size="lg" />
                      <div>
                        <div className="text-[17px] font-extrabold text-[#182334]">
                          {session.buddyName} {session.buddyVerified ? '✓' : ''}
                        </div>
                        <div className="text-[12.5px] text-[#526071] mt-0.5">
                          {session.type} · {session.durationLabel}
                        </div>
                      </div>
                    </div>
                    <span className="px-3.5 py-1 rounded-full bg-[#E3F1EA] text-[#182334] text-[11.5px] font-semibold shrink-0">
                      Selesai
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-[12.5px] text-[#475569] mt-4">
                    <Calendar className="w-4 h-4 text-[#64748B] shrink-0" />
                    <span>
                      {session.dateLabel} · {session.timeLabel}
                    </span>
                  </div>

                  <div className="flex items-center justify-between mt-3">
                    <span className="text-[16px] font-extrabold text-[#182334] tabular-nums">
                      {formatRupiah(session.price)}
                    </span>
                    {session.review ? (
                      <span className="inline-flex items-center gap-1 text-[12px] font-medium text-[#334155] tabular-nums">
                        <Star className="w-3.5 h-3.5 fill-[#182334] text-[#182334]" />
                        <span>{session.review.rating}/5 · Ulasan terkirim</span>
                      </span>
                    ) : (
                      <span className="text-[12px] text-[#526071]">
                        Menunggu ulasanmu
                      </span>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={() => onBookAgain(session)}
                    className="mt-4 w-full h-12 rounded-full tc-btn-primary flex items-center justify-center gap-2 text-[13.5px] cursor-pointer"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>Pesan lagi dengan {session.buddyName}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onOpenReview(session)}
                    className="mt-3 w-full py-1.5 text-[13px] font-semibold text-[#334155] hover:text-[#182334] cursor-pointer"
                  >
                    {session.review ? 'Lihat ulasanmu' : 'Tulis ulasan'}
                  </button>
                </article>
              ))}
            </div>
          )}

          {/* Mint Callout */}
          <div className="bg-[#DFEFE8] rounded-[22px] p-4 flex items-start gap-3">
            <Heart className="w-5 h-5 text-[#182334] shrink-0 mt-0.5" strokeWidth={1.8} />
            <div>
              <div className="text-[13.5px] font-bold text-[#182334]">
                Mau ditemani lagi?
              </div>
              <p className="text-[12.5px] text-[#334155] mt-1 leading-relaxed">
                Temukan buddy yang sama, atau kenalan dengan teman baru. Tidak perlu menunggu hari yang berat.
              </p>
            </div>
          </div>

          <div className="flex justify-center pt-2">
            <DuoMascots />
          </div>
        </div>
      )}
    </div>
  );
};
