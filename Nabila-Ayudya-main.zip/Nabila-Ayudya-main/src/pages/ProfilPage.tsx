import React, { useState } from 'react';
import {
  Bell,
  ChevronRight,
  Lock,
  MoreHorizontal,
  Plus,
  ShieldCheck,
  SquarePen,
  User,
  UserX,
  X,
} from 'lucide-react';
import { BuddyAvatar } from '../components/assets/Mascots';
import { MascotVariant, UserProfile } from '../types';

interface ProfilPageProps {
  user: UserProfile;
  onUpdateUser: (patch: Partial<UserProfile>) => void;
  onOpenPrivacySheet: () => void;
  onShowToast: (msg: string) => void;
}

const SUGGESTED_INTERESTS = [
  'Musik',
  'Kampus',
  'Journaling',
  'Membaca',
  'Film & Series',
  'Kopi & Santai',
  'Seni & Desain',
  'Pengembangan Diri',
];

export const ProfilPage: React.FC<ProfilPageProps> = ({
  user,
  onUpdateUser,
  onOpenPrivacySheet,
  onShowToast,
}) => {
  const [editProfileOpen, setEditProfileOpen] = useState(false);
  const [editInterestsOpen, setEditInterestsOpen] = useState(false);
  const [birthModalOpen, setBirthModalOpen] = useState(false);
  const [blockedModalOpen, setBlockedModalOpen] = useState(false);

  // Local form states
  const [draftName, setDraftName] = useState(user.name);
  const [draftAge, setDraftAge] = useState(String(user.age));
  const [draftEmail, setDraftEmail] = useState(user.email);
  const [draftMascot, setDraftMascot] = useState<MascotVariant>(user.mascot);
  const [draftBirthDate, setDraftBirthDate] = useState(user.birthDate);
  const [newInterest, setNewInterest] = useState('');

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAge = Math.max(15, Math.min(99, Number(draftAge) || user.age));
    onUpdateUser({
      name: draftName.trim() || user.name,
      age: parsedAge,
      email: draftEmail.trim() || user.email,
      mascot: draftMascot,
    });
    setEditProfileOpen(false);
    onShowToast('Profil berhasil diperbarui.');
  };

  const toggleInterest = (item: string) => {
    const exists = user.interests.includes(item);
    if (exists && user.interests.length <= 1) {
      onShowToast('Pilih minimal 1 hal yang kamu suka.');
      return;
    }
    onUpdateUser({
      interests: exists
        ? user.interests.filter((i) => i !== item)
        : [...user.interests, item],
    });
  };

  const handleAddInterest = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = newInterest.trim();
    if (!cleaned) return;
    if (!user.interests.includes(cleaned)) {
      onUpdateUser({ interests: [...user.interests, cleaned] });
    }
    setNewInterest('');
  };

  const handleUnblock = (id: string, name: string) => {
    onUpdateUser({
      blockedAccounts: user.blockedAccounts.filter((b) => b.id !== id),
    });
    onShowToast(`${name} dihapus dari daftar blokir.`);
  };

  return (
    <div className="px-5 pt-3 pb-6 md:px-0">
      {/* Header */}
      <div className="flex items-center justify-between h-12 mb-2">
        <h1 className="text-[18px] font-bold text-[#182334] tracking-tight">
          Profil
        </h1>
        <button
          type="button"
          onClick={onOpenPrivacySheet}
          aria-label="Pengaturan & Privasi"
          className="w-10 h-10 rounded-full hover:bg-white/60 flex items-center justify-center text-[#182334] cursor-pointer"
        >
          <MoreHorizontal className="w-5 h-5" />
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-7 space-y-6">
          {/* Profile Summary Card */}
          <section className="tc-card p-5 flex items-center justify-between gap-4">
            <div className="flex items-center gap-4 min-w-0">
              <BuddyAvatar variant={user.mascot} size="xl" />
              <div className="min-w-0">
                <h2 className="text-[24px] font-extrabold text-[#182334] tracking-tight leading-tight truncate">
                  {user.name}
                </h2>
                <p className="text-[12.5px] text-[#526071] mt-0.5 truncate">
                  {user.age} tahun · {user.joinedLabel}
                </p>
                <p className="text-[12.5px] text-[#64748B] truncate">
                  {user.email}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setDraftName(user.name);
                setDraftAge(String(user.age));
                setDraftEmail(user.email);
                setDraftMascot(user.mascot);
                setEditProfileOpen(true);
              }}
              aria-label="Edit profil"
              className="w-10 h-10 rounded-full hover:bg-[#F3F6FC] flex items-center justify-center text-[#334155] transition-colors cursor-pointer shrink-0"
            >
              <SquarePen className="w-[18px] h-[18px]" strokeWidth={1.8} />
            </button>
          </section>

          {/* Hal yang aku suka */}
          <section>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-[18px] font-extrabold text-[#182334] tracking-tight">
                Hal yang aku suka
              </h3>
              <button
                type="button"
                onClick={() => setEditInterestsOpen(true)}
                className="text-[13px] font-semibold text-[#475569] hover:text-[#182334] cursor-pointer"
              >
                Ubah →
              </button>
            </div>

            <div className="flex flex-wrap gap-2">
              {user.interests.map((interest) => (
                <span
                  key={interest}
                  className="px-4 py-2 rounded-full bg-white text-[13px] font-medium text-[#182334] shadow-[0_2px_10px_rgba(24,35,52,0.03)]"
                >
                  {interest}
                </span>
              ))}
            </div>
          </section>
        </div>

        <div className="lg:col-span-5 space-y-4">
          {/* Pengaturan */}
          <section>
            <h3 className="text-[18px] font-extrabold text-[#182334] tracking-tight mb-3">
              Pengaturan
            </h3>

            <div className="tc-card overflow-hidden divide-y divide-slate-100">
              <button
                type="button"
                onClick={() => {
                  setDraftBirthDate(user.birthDate);
                  setBirthModalOpen(true);
                }}
                className="w-full flex items-center justify-between px-5 py-4 hover:bg-slate-50/80 transition-colors cursor-pointer text-left"
              >
                <span className="flex items-center gap-3.5 text-[14px] font-semibold text-[#182334]">
                  <User className="w-[18px] h-[18px] text-[#475569]" strokeWidth={1.7} />
                  <span>Akun &amp; tanggal lahir</span>
                </span>
                <ChevronRight className="w-4 h-4 text-[#64748B]" />
              </button>

              <button
                type="button"
                onClick={() => {
                  const next = !user.notificationsEnabled;
                  onUpdateUser({ notificationsEnabled: next });
                  onShowToast(
                    next
                      ? 'Notifikasi pengingat sesi diaktifkan.'
                      : 'Notifikasi pengingat sesi dinonaktifkan.'
                  );
                }}
                className="w-full flex items-center justify-between px-5 py-4 hover:bg-slate-50/80 transition-colors cursor-pointer text-left"
              >
                <span className="flex items-center gap-3.5 text-[14px] font-semibold text-[#182334]">
                  <Bell className="w-[18px] h-[18px] text-[#475569]" strokeWidth={1.7} />
                  <span>Notifikasi sesi</span>
                </span>
                <span className="flex items-center gap-2 text-[12.5px] text-[#526071]">
                  <span>{user.notificationsEnabled ? 'Aktif' : 'Nonaktif'}</span>
                  <ChevronRight className="w-4 h-4 text-[#64748B]" />
                </span>
              </button>

              <button
                type="button"
                onClick={onOpenPrivacySheet}
                className="w-full flex items-center justify-between px-5 py-4 hover:bg-slate-50/80 transition-colors cursor-pointer text-left"
              >
                <span className="flex items-center gap-3.5 text-[14px] font-semibold text-[#182334]">
                  <ShieldCheck className="w-[18px] h-[18px] text-[#475569]" strokeWidth={1.7} />
                  <span>Privasi &amp; keamanan</span>
                </span>
                <ChevronRight className="w-4 h-4 text-[#64748B]" />
              </button>

              <button
                type="button"
                onClick={() => setBlockedModalOpen(true)}
                className="w-full flex items-center justify-between px-5 py-4 hover:bg-slate-50/80 transition-colors cursor-pointer text-left"
              >
                <span className="flex items-center gap-3.5 text-[14px] font-semibold text-[#182334]">
                  <UserX className="w-[18px] h-[18px] text-[#475569]" strokeWidth={1.7} />
                  <span>Akun yang diblokir</span>
                </span>
                <span className="flex items-center gap-2 text-[12.5px] text-[#526071]">
                  {user.blockedAccounts.length > 0 && (
                    <span>{user.blockedAccounts.length}</span>
                  )}
                  <ChevronRight className="w-4 h-4 text-[#64748B]" />
                </span>
              </button>
            </div>
          </section>

          {/* Privacy Assurance Mint Banner */}
          <div className="bg-[#DFEFE8] rounded-[22px] p-4 flex items-start gap-3">
            <Lock className="w-5 h-5 text-[#182334] shrink-0 mt-0.5" strokeWidth={1.7} />
            <div>
              <div className="text-[13.5px] font-bold text-[#182334]">
                Ceritamu bukan konsumsi publik
              </div>
              <p className="text-[12.5px] text-[#334155] mt-1 leading-relaxed">
                Percakapan sesi tidak ditampilkan di komunitas. Kamu menentukan apa yang ingin dibagikan.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Edit Profile Modal */}
      {editProfileOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#182334]/30 backdrop-blur-[2px] px-5"
          role="dialog"
          aria-modal="true"
        >
          <form
            onSubmit={handleSaveProfile}
            className="w-full max-w-[400px] bg-white rounded-[28px] p-6 shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-[18px] font-extrabold text-[#182334]">
                Edit profil
              </h3>
              <button
                type="button"
                onClick={() => setEditProfileOpen(false)}
                className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-[#526071] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <label className="block text-[12px] font-bold text-[#526071] mb-1.5">
                Pilih karakter profil
              </label>
              <div className="flex gap-3">
                {(['periwinkle', 'mint'] as MascotVariant[]).map((variant) => (
                  <button
                    key={variant}
                    type="button"
                    onClick={() => setDraftMascot(variant)}
                    className={`flex-1 p-3 rounded-2xl border flex items-center justify-center gap-2 cursor-pointer ${
                      draftMascot === variant
                        ? 'bg-[#DCE4FA] border-[#93A8E6]'
                        : 'bg-[#F8FAFC] border-slate-200'
                    }`}
                  >
                    <BuddyAvatar variant={variant} size="sm" />
                    <span className="text-[13px] font-bold text-[#182334]">
                      {variant === 'periwinkle' ? 'Biru' : 'Mint'}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-[12px] font-bold text-[#526071] mb-1">
                Nama panggilan
              </label>
              <input
                type="text"
                value={draftName}
                onChange={(e) => setDraftName(e.target.value)}
                className="w-full h-11 px-4 rounded-2xl bg-[#F4F7FC] text-[14px] text-[#182334] focus:outline-none focus:ring-2 focus:ring-[#93A8E6]"
              />
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-[12px] font-bold text-[#526071] mb-1">
                  Usia
                </label>
                <input
                  type="number"
                  min={15}
                  max={99}
                  value={draftAge}
                  onChange={(e) => setDraftAge(e.target.value)}
                  className="w-full h-11 px-4 rounded-2xl bg-[#F4F7FC] text-[14px] text-[#182334] focus:outline-none focus:ring-2 focus:ring-[#93A8E6]"
                />
              </div>
              <div className="col-span-2">
                <label className="block text-[12px] font-bold text-[#526071] mb-1">
                  Email
                </label>
                <input
                  type="email"
                  value={draftEmail}
                  onChange={(e) => setDraftEmail(e.target.value)}
                  className="w-full h-11 px-4 rounded-2xl bg-[#F4F7FC] text-[14px] text-[#182334] focus:outline-none focus:ring-2 focus:ring-[#93A8E6]"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full h-12 rounded-full tc-btn-primary text-[14px] cursor-pointer"
            >
              Simpan perubahan
            </button>
          </form>
        </div>
      )}

      {/* Edit Interests Modal */}
      {editInterestsOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#182334]/30 backdrop-blur-[2px] px-5"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-[400px] bg-white rounded-[28px] p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-[18px] font-extrabold text-[#182334]">
                Hal yang aku suka
              </h3>
              <button
                type="button"
                onClick={() => setEditInterestsOpen(false)}
                className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-[#526071] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex flex-wrap gap-2">
              {Array.from(new Set([...SUGGESTED_INTERESTS, ...user.interests])).map(
                (item) => {
                  const active = user.interests.includes(item);
                  return (
                    <button
                      key={item}
                      type="button"
                      onClick={() => toggleInterest(item)}
                      className={`px-3.5 py-2 rounded-full text-[13px] font-semibold transition-colors cursor-pointer ${
                        active
                          ? 'bg-[#93A8E6] text-[#182334]'
                          : 'bg-[#F2F5FB] text-[#526071]'
                      }`}
                    >
                      {item}
                    </button>
                  );
                }
              )}
            </div>

            <form onSubmit={handleAddInterest} className="flex gap-2">
              <input
                type="text"
                value={newInterest}
                onChange={(e) => setNewInterest(e.target.value)}
                placeholder="Tambah topik lain..."
                className="flex-1 h-10 px-4 rounded-full bg-[#F4F7FC] text-[13px] text-[#182334] focus:outline-none focus:ring-2 focus:ring-[#93A8E6]"
              />
              <button
                type="submit"
                aria-label="Tambah minat"
                className="w-10 h-10 rounded-full tc-btn-primary flex items-center justify-center cursor-pointer"
              >
                <Plus className="w-4 h-4" />
              </button>
            </form>

            <button
              type="button"
              onClick={() => {
                setEditInterestsOpen(false);
                onShowToast('Daftar minat diperbarui.');
              }}
              className="w-full h-11 rounded-full tc-btn-primary text-[14px] cursor-pointer"
            >
              Selesai
            </button>
          </div>
        </div>
      )}

      {/* Account & Birth Date Modal */}
      {birthModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#182334]/30 backdrop-blur-[2px] px-5"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-[380px] bg-white rounded-[28px] p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-[17px] font-extrabold text-[#182334]">
                Akun &amp; tanggal lahir
              </h3>
              <button
                type="button"
                onClick={() => setBirthModalOpen(false)}
                className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-[#526071] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div>
              <label className="block text-[12px] font-bold text-[#526071] mb-1">
                Tanggal lahir
              </label>
              <input
                type="date"
                value={draftBirthDate}
                onChange={(e) => setDraftBirthDate(e.target.value)}
                className="w-full h-11 px-4 rounded-2xl bg-[#F4F7FC] text-[14px] text-[#182334] focus:outline-none focus:ring-2 focus:ring-[#93A8E6]"
              />
            </div>
            <button
              type="button"
              onClick={() => {
                onUpdateUser({ birthDate: draftBirthDate });
                setBirthModalOpen(false);
                onShowToast('Informasi akun disimpan.');
              }}
              className="w-full h-11 rounded-full tc-btn-primary text-[14px] cursor-pointer"
            >
              Simpan
            </button>
          </div>
        </div>
      )}

      {/* Blocked Accounts Modal */}
      {blockedModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#182334]/30 backdrop-blur-[2px] px-5"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-[380px] bg-white rounded-[28px] p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-[17px] font-extrabold text-[#182334]">
                Akun yang diblokir
              </h3>
              <button
                type="button"
                onClick={() => setBlockedModalOpen(false)}
                className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-[#526071] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {user.blockedAccounts.length === 0 ? (
              <p className="text-[13.5px] text-[#526071] py-3">
                Tidak ada akun yang diblokir saat ini.
              </p>
            ) : (
              <div className="space-y-2.5">
                {user.blockedAccounts.map((acc) => (
                  <div
                    key={acc.id}
                    className="flex items-center justify-between p-3.5 rounded-2xl bg-[#F4F7FC]"
                  >
                    <div>
                      <div className="text-[13.5px] font-bold text-[#182334]">
                        {acc.name}
                      </div>
                      <div className="text-[11.5px] text-[#64748B]">
                        Diblokir {acc.blockedAt}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleUnblock(acc.id, acc.name)}
                      className="px-3 py-1.5 rounded-full bg-white text-[12px] font-bold text-[#182334] border border-slate-200 cursor-pointer"
                    >
                      Buka blokir
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
