import React, { useState } from 'react';
import { Heart, Lock, Send } from 'lucide-react';
import { BuddyAvatar } from '../components/assets/Mascots';
import { CommunityPost, UserProfile } from '../types';

interface KomunitasPageProps {
  posts: CommunityPost[];
  user: UserProfile;
  onAddPost: (topic: string, content: string) => void;
  onToggleHug: (postId: string) => void;
}

const TOPICS = ['Semua', 'Kampus', 'Journaling', 'Musik'];

export const KomunitasPage: React.FC<KomunitasPageProps> = ({
  posts,
  user,
  onAddPost,
  onToggleHug,
}) => {
  const [selectedTopic, setSelectedTopic] = useState('Semua');
  const [newTopic, setNewTopic] = useState('Kampus');
  const [newContent, setNewContent] = useState('');

  const filteredPosts =
    selectedTopic === 'Semua'
      ? posts
      : posts.filter((p) => p.topic === selectedTopic);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = newContent.trim();
    if (!cleaned) return;
    onAddPost(newTopic, cleaned);
    setNewContent('');
  };

  return (
    <div className="px-5 pt-4 pb-6 md:px-0">
      <div className="mb-5">
        <h1 className="text-[28px] md:text-[32px] font-extrabold text-[#182334] tracking-tight leading-[1.15]">
          Ruang cerita bersama.
        </h1>
        <p className="text-[13.5px] text-[#475569] mt-1.5">
          Bagikan hal kecil hari ini secara anonim. Saling menguatkan tanpa menghakimi.
        </p>
      </div>

      {/* Privacy Notice */}
      <div className="bg-[#DFEFE8] rounded-[22px] p-4 flex items-start gap-3 mb-5">
        <Lock className="w-5 h-5 text-[#182334] shrink-0 mt-0.5" strokeWidth={1.7} />
        <div>
          <div className="text-[13.5px] font-bold text-[#182334]">
            Identitasmu tetap terjaga
          </div>
          <p className="text-[12.5px] text-[#334155] mt-0.5 leading-relaxed">
            {user.anonymousByDefault
              ? 'Nama samaran aktif otomatis di komunitas. Cerita privat di ruang chat tidak pernah masuk ke sini.'
              : 'Kamu bisa mengaktifkan nama samaran kapan saja lewat menu Profil → Privasi.'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Composer */}
        <div className="lg:col-span-5">
          <form onSubmit={handleSubmit} className="tc-card p-5 space-y-3">
            <div className="text-[15px] font-extrabold text-[#182334]">
              Titip satu cerita singkat
            </div>

            <div className="flex flex-wrap gap-1.5">
              {TOPICS.filter((t) => t !== 'Semua').map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setNewTopic(t)}
                  className={`px-3 py-1 rounded-full text-[12px] font-semibold cursor-pointer ${
                    newTopic === t
                      ? 'bg-[#93A8E6] text-[#182334]'
                      : 'bg-[#F2F5FB] text-[#526071]'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>

            <textarea
              value={newContent}
              onChange={(e) => setNewContent(e.target.value.slice(0, 280))}
              rows={3}
              placeholder="Apa yang sedang kamu syukuri atau rasakan pelan-pelan hari ini?"
              className="w-full rounded-2xl bg-[#F4F7FC] p-3.5 text-[13.5px] text-[#182334] placeholder:text-[#94A3B8] resize-none focus:outline-none focus:ring-2 focus:ring-[#93A8E6]"
            />

            <div className="flex items-center justify-between">
              <span className="text-[11.5px] text-[#64748B] tabular-nums">
                {newContent.length}/280
              </span>
              <button
                type="submit"
                className="px-5 h-10 rounded-full tc-btn-primary inline-flex items-center gap-2 text-[13px] cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Bagikan</span>
              </button>
            </div>
          </form>
        </div>

        {/* Feed */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {TOPICS.map((topic) => (
              <button
                key={topic}
                type="button"
                onClick={() => setSelectedTopic(topic)}
                className={`px-4 py-2 rounded-full text-[12.5px] font-bold whitespace-nowrap transition-colors cursor-pointer ${
                  selectedTopic === topic
                    ? 'bg-[#93A8E6] text-[#182334]'
                    : 'bg-white text-[#475569] hover:text-[#182334]'
                }`}
              >
                {topic}
              </button>
            ))}
          </div>

          {filteredPosts.map((post) => (
            <article key={post.id} className="tc-card p-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <BuddyAvatar variant={post.mascot} size="sm" />
                  <div>
                    <div className="text-[14px] font-bold text-[#182334]">
                      {post.alias}
                    </div>
                    <div className="text-[11.5px] text-[#64748B]">
                      {post.topic} · {post.timeAgo}
                    </div>
                  </div>
                </div>
              </div>

              <p className="text-[13.5px] text-[#334155] leading-relaxed mt-3">
                {post.content}
              </p>

              <div className="mt-3.5 pt-3 border-t border-slate-100 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => onToggleHug(post.id)}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-[12.5px] font-semibold transition-colors cursor-pointer tabular-nums ${
                    post.huggedByMe
                      ? 'bg-[#F7D7CE] text-[#182334]'
                      : 'bg-[#F4F7FC] text-[#526071] hover:bg-[#EAEFF9]'
                  }`}
                >
                  <Heart
                    className={`w-3.5 h-3.5 ${
                      post.huggedByMe ? 'fill-[#182334]' : ''
                    }`}
                  />
                  <span>Kirim peluk · {post.hugsCount}</span>
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
};
