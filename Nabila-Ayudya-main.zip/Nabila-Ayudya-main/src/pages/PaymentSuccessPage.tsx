import React from 'react';
import { CalendarHeart, CheckCircle2 } from 'lucide-react';
import { BuddyAvatar, MintMascot } from '../components/assets/Mascots';
import { TopBar } from '../components/common/TopBar';
import { formatRupiah } from '../data/mockData';
import { SessionItem } from '../types';

interface PaymentSuccessPageProps {
  session: SessionItem;
  onViewSessions: () => void;
  onBackHome: () => void;
  onShowToast: (msg: string) => void;
}

export const PaymentSuccessPage: React.FC<PaymentSuccessPageProps> = ({
  session,
  onViewSessions,
  onBackHome,
  onShowToast,
}) => {
  return (
    <div className="px-5 pt-2 pb-10 md:px-0">
      <TopBar
        title="Pembayaran"
        onBack={onViewSessions}
        onMore={() => onShowToast(`ID Pemesanan: ${session.orderId}`)}
      />

      <div className="flex flex-col items-center text-center mt-3 mb-6">
        <MintMascot className="w-28 h-28 mb-2" />

        <span className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-[#DFEFE8] text-[#182334] text-[12.5px] font-bold">
          <CheckCircle2 className="w-4 h-4 text-[#182334]" strokeWidth={1.8} />
          <span>Pembayaran berhasil</span>
        </span>

        <h2 className="text-[28px] md:text-[32px] font-extrabold text-[#182334] tracking-tight mt-4">
          Waktumu sudah aman.
        </h2>
        <p className="text-[13.5px] text-[#475569] leading-relaxed mt-2 max-w-[300px]">
          {session.buddyName} akan menemanimu. Sampai ketemu di ruang cerita, ya.
        </p>
      </div>

      {/* Session Card */}
      <div className="tc-card p-5 mb-3.5">
        <div className="flex items-center gap-3.5">
          <BuddyAvatar variant={session.buddyMascot} size="lg" />
          <div>
            <div className="text-[16px] font-extrabold text-[#182334]">
              {session.buddyName} · {session.type}
            </div>
            <div className="text-[12.5px] text-[#526071] mt-0.5">
              {session.dateLabel} · {session.timeLabel}
            </div>
          </div>
        </div>
        <div className="flex items-center justify-between mt-4 pt-1">
          <span className="text-[13px] text-[#475569]">
            {session.durationLabel}
          </span>
          <span className="text-[17px] font-extrabold text-[#182334] tabular-nums">
            {formatRupiah(session.price)}
          </span>
        </div>
      </div>

      {/* Order Details Card */}
      <div className="tc-card p-5 mb-7 space-y-3 text-[13.5px]">
        <div className="flex items-center justify-between">
          <span className="text-[#526071]">ID pemesanan</span>
          <span className="font-bold text-[#182334] tabular-nums">
            {session.orderId}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-[#526071]">Metode</span>
          <span className="font-bold text-[#182334] tabular-nums">
            {session.paymentMethodLabel} · {formatRupiah(session.price)}
          </span>
        </div>
      </div>

      {/* Actions */}
      <button
        type="button"
        onClick={onViewSessions}
        className="w-full h-13 rounded-full tc-btn-primary flex items-center justify-center gap-2 text-[15px] cursor-pointer"
      >
        <CalendarHeart className="w-4 h-4" />
        <span>Lihat sesi saya</span>
      </button>

      <button
        type="button"
        onClick={onBackHome}
        className="mt-4 w-full py-2 text-[13.5px] font-semibold text-[#334155] hover:text-[#182334] cursor-pointer"
      >
        Kembali ke Home
      </button>
    </div>
  );
};
