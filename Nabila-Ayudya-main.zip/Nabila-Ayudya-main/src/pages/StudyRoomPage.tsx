import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  ArrowUp,
  ArrowUpRight,
  Clock,
  Flag,
  HeartHandshake,
  Leaf,
  Lock,
  Pause,
  Play,
  Plus,
} from 'lucide-react';
import { BuddyAvatar } from '../components/assets/Mascots';
import { formatTimer } from '../data/mockData';
import { SessionItem } from '../types';

interface StudyRoomPageProps {
  session: SessionItem;
  isTyping: boolean;
  onSendMessage: (sessionId: string, text: string) => void;
  onEndSession: (sessionId: string) => void;
  onBack: () => void;
  onOpenBantuanProfesional: () => void;
  onShowToast: (msg: string) => void;
}

const FOCUS_SECONDS = 25 * 60;
const BREAK_SECONDS = 5 * 60;

export const StudyRoomPage: React.FC<StudyRoomPageProps> = ({
  session,
  isTyping,
  onSendMessage,
  onEndSession,
  onBack,
  onOpenBantuanProfesional,
  onShowToast,
}) => {
  const [mode, setMode] = useState<'focus' | 'break'>('focus');
  const [cycle, setCycle] = useState<1 | 2>(1);
  // Start at 17:10 matching the Figma Pomodoro screenshot, live ticking
  const [pomoSeconds, setPomoSeconds] = useState<number>(17 * 60 + 10);
  const [isRunning, setIsRunning] = useState<boolean>(true);
  const [input, setInput] = useState('');
  const [showEndConfirm, setShowEndConfirm] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!isRunning) return;
    const id = window.setInterval(() => {
      setPomoSeconds((prev) => {
        if (prev <= 1) {
          if (mode === 'focus') {
            setMode('break');
            onShowToast('Sesi fokus selesai! Waktunya istirahat 5 menit.');
            return BREAK_SECONDS;
          } else {
            setMode('focus');
            setCycle(2);
            onShowToast('Istirahat selesai. Lanjut fokus sesi 2/2!');
            return FOCUS_SECONDS;
          }
        }
        return prev - 1;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [isRunning, mode, onShowToast]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [session.messages.length, isTyping]);

  const totalForMode = mode === 'focus' ? FOCUS_SECONDS : BREAK_SECONDS;
  const elapsedRatio = Math.min(1, Math.max(0, (totalForMode - pomoSeconds) / totalForMode));
  const radius = 68;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference * (1 - elapsedRatio);

  const handleToggleBreak = () => {
    if (mode === 'focus') {
      setMode('break');
      setPomoSeconds(BREAK_SECONDS);
      setIsRunning(true);
      onShowToast('Masuk mode istirahat 5 menit.');
    } else {
      setMode('focus');
      setPomoSeconds(FOCUS_SECONDS);
      setCycle((prev) => (prev === 1 ? 2 : 1));
      setIsRunning(true);
      onShowToast('Kembali ke mode fokus 25 menit.');
    }
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed) return;
    onSendMessage(session.id, trimmed);
    setInput('');
  };

  return (
    <div className="px-4 pt-3 pb-6 md:px-0 flex flex-col min-h-[calc(100dvh-1rem)] md:min-h-[calc(100dvh-3rem)]">
      {/* Header */}
      <header className="flex items-center justify-between py-2">
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={onBack}
            aria-label="Kembali"
            className="w-9 h-9 rounded-full hover:bg-white/70 flex items-center justify-center text-[#182334] cursor-pointer shrink-0"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <BuddyAvatar variant={session.buddyMascot} size="md" />
          <div className="min-w-0">
            <div className="text-[17px] font-extrabold text-[#182334] leading-tight truncate">
              {session.buddyName} {session.buddyVerified ? '✓' : ''}
            </div>
            <div className="text-[12px] text-[#526071] truncate">
              Study · {session.durationLabel} · Terhubung
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={() => onShowToast('Ruang belajar aman dan menjaga privasi.')}
          aria-label="Keamanan ruang belajar"
          className="w-10 h-10 rounded-full hover:bg-white/70 flex items-center justify-center text-[#182334] cursor-pointer shrink-0"
        >
          <Flag className="w-5 h-5" strokeWidth={1.7} />
        </button>
      </header>

      {/* Live Session Timer Pill */}
      <div className="mt-2 bg-white rounded-full px-4 py-2.5 flex items-center justify-between shadow-[0_3px_14px_rgba(24,35,52,0.04)]">
        <div className="flex items-center gap-2 text-[13px] font-semibold text-[#182334] tabular-nums">
          <Clock className="w-4 h-4 text-[#334155]" />
          <span>Sisa waktu {formatTimer(session.remainingSeconds)}</span>
        </div>
        <button
          type="button"
          onClick={() => setShowEndConfirm(true)}
          className="text-[13px] font-bold text-[#182334] hover:text-rose-700 transition-colors cursor-pointer"
        >
          Akhiri sesi
        </button>
      </div>

      {/* Privacy Notice */}
      <div className="flex items-center justify-center gap-1.5 text-[11.5px] text-[#475569] mt-3 mb-3.5">
        <Lock className="w-3.5 h-3.5 text-[#526071]" />
        <span>Jaga privasi. Tidak perlu berbagi kontak pribadi.</span>
      </div>

      {/* Pomodoro Card */}
      <section className="tc-card p-5 mb-4">
        <div className="flex items-center justify-between mb-3">
          <span className="text-[12px] font-extrabold tracking-wider uppercase text-[#182334]">
            {mode === 'focus'
              ? `POMODORO · FOKUS ${cycle}/2`
              : 'POMODORO · ISTIRAHAT'}
          </span>
          <Leaf className="w-4 h-4 text-[#475569]" strokeWidth={1.7} />
        </div>

        {/* Circular SVG Ring */}
        <div className="flex flex-col items-center my-2">
          <div className="relative w-[170px] h-[170px] flex items-center justify-center">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 160 160">
              <circle
                cx="80"
                cy="80"
                r={radius}
                fill="none"
                stroke="#EAEFF9"
                strokeWidth="7"
              />
              <circle
                cx="80"
                cy="80"
                r={radius}
                fill="none"
                stroke={mode === 'focus' ? '#93A8E6' : '#A3D9BE'}
                strokeWidth="7"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                className="transition-all duration-500"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-[32px] font-extrabold text-[#182334] tracking-tight tabular-nums leading-none">
                {formatTimer(pomoSeconds)}
              </span>
              <span className="text-[11.5px] text-[#526071] mt-1.5">
                {mode === 'focus'
                  ? 'dari 25 menit fokus'
                  : 'dari 5 menit istirahat'}
              </span>
            </div>
          </div>
        </div>

        {/* Pomodoro Controls */}
        <div className="grid grid-cols-2 gap-2.5 mt-4">
          <button
            type="button"
            onClick={() => setIsRunning((prev) => !prev)}
            className="h-11 rounded-full border border-slate-200 bg-white hover:bg-slate-50 flex items-center justify-center gap-2 text-[13.5px] font-bold text-[#182334] transition-colors cursor-pointer"
          >
            {isRunning ? (
              <>
                <Pause className="w-4 h-4 text-[#475569]" />
                <span>Jeda</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 text-[#475569]" />
                <span>Lanjut</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={handleToggleBreak}
            className="h-11 rounded-full border border-slate-200 bg-white hover:bg-slate-50 flex items-center justify-center text-[13.5px] font-bold text-[#182334] transition-colors cursor-pointer"
          >
            {mode === 'focus' ? 'Istirahat 5 menit' : 'Fokus 25 menit'}
          </button>
        </div>
      </section>

      {/* Study Messages */}
      <div className="flex-1 space-y-3.5 overflow-y-auto pb-4">
        {session.messages.map((msg) =>
          msg.sender === 'buddy' ? (
            <div key={msg.id} className="flex flex-col items-start">
              <div className="bg-white rounded-[22px] rounded-tl-md px-4 py-3.5 max-w-[85%] shadow-[0_2px_12px_rgba(24,35,52,0.03)] text-[14px] leading-relaxed text-[#182334]">
                {msg.text}
              </div>
              <span className="text-[11px] text-[#64748B] mt-1.5 ml-1 tabular-nums">
                {msg.time}
              </span>
            </div>
          ) : (
            <div key={msg.id} className="flex flex-col items-end">
              <div className="bg-[#C8D4F5] rounded-[22px] rounded-tr-md px-4 py-3.5 max-w-[85%] text-[14px] leading-relaxed text-[#182334]">
                {msg.text}
              </div>
              <span className="text-[11px] text-[#64748B] mt-1.5 mr-1 tabular-nums">
                {msg.time} · {msg.read ? 'Dibaca' : 'Terkirim'}
              </span>
            </div>
          )
        )}

        {isTyping && (
          <div className="flex items-start">
            <div className="bg-white rounded-full px-4 py-2 inline-flex items-center gap-2 shadow-xs">
              <span className="text-[12px] text-[#475569] font-medium">
                {session.buddyName} mengetik...
              </span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Composer & Safety Footer */}
      <div className="space-y-3 pt-2">
        <form
          onSubmit={handleSend}
          className="bg-white rounded-full p-1.5 pl-2.5 flex items-center gap-2 shadow-[0_4px_20px_rgba(24,35,52,0.05)]"
        >
          <button
            type="button"
            onClick={() =>
              onSendMessage(session.id, 'Aku sudah selesai 1 bagian, lanjut target berikutnya!')
            }
            aria-label="Kirim update progres cepat"
            className="w-9 h-9 rounded-full hover:bg-slate-100 flex items-center justify-center text-[#334155] cursor-pointer shrink-0"
          >
            <Plus className="w-5 h-5" />
          </button>

          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Tulis ceritamu di sini..."
            className="flex-1 bg-transparent text-[14px] text-[#182334] placeholder:text-[#94A3B8] focus:outline-none min-w-0"
          />

          <button
            type="submit"
            aria-label="Kirim pesan"
            className="w-10 h-10 rounded-full bg-[#93A8E6] hover:bg-[#8298DD] flex items-center justify-center text-[#182334] transition-colors cursor-pointer shrink-0"
          >
            <ArrowUp className="w-5 h-5" strokeWidth={2} />
          </button>
        </form>

        <button
          type="button"
          onClick={onOpenBantuanProfesional}
          className="w-full h-12 rounded-full bg-[#F7D7CE] hover:bg-[#F3C9BD] flex items-center justify-center gap-2.5 text-[14px] font-bold text-[#182334] transition-colors cursor-pointer"
        >
          <HeartHandshake className="w-[18px] h-[18px]" strokeWidth={1.8} />
          <span>Butuh bantuan profesional?</span>
          <ArrowUpRight className="w-4 h-4" />
        </button>

        <p className="text-center text-[11px] text-[#526071]">
          Buddy bukan psikolog atau layanan krisis.
        </p>
      </div>

      {showEndConfirm && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#182334]/30 backdrop-blur-[2px] px-5"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-[380px] bg-white rounded-[28px] p-6 shadow-2xl">
            <h3 className="text-[18px] font-extrabold text-[#182334]">
              Akhiri sesi belajar?
            </h3>
            <p className="text-[13.5px] text-[#475569] mt-2 leading-relaxed">
              Setelah sesi berakhir, kamu bisa memberikan ulasan singkat untuk {session.buddyName}.
            </p>
            <div className="mt-5 flex gap-2.5">
              <button
                type="button"
                onClick={() => setShowEndConfirm(false)}
                className="flex-1 h-11 rounded-full border border-slate-200 text-[13.5px] font-bold text-[#475569] cursor-pointer"
              >
                Lanjut belajar
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowEndConfirm(false);
                  onEndSession(session.id);
                }}
                className="flex-1 h-11 rounded-full tc-btn-primary text-[13.5px] cursor-pointer"
              >
                Ya, akhiri
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
