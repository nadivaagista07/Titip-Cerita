import React, { useEffect, useState } from 'react';
import { Download, ScanLine } from 'lucide-react';
import { QrisIllustrationSvg } from '../components/assets/Mascots';
import { TopBar } from '../components/common/TopBar';
import { formatRupiah, formatTimer } from '../data/mockData';
import { BookingDraft } from '../types';

interface PaymentQrisPageProps {
  draft: BookingDraft;
  onBack: () => void;
  onChangeMethod: () => void;
  onConfirmPayment: () => void;
  onShowToast: (msg: string) => void;
}

export const PaymentQrisPage: React.FC<PaymentQrisPageProps> = ({
  draft,
  onBack,
  onChangeMethod,
  onConfirmPayment,
  onShowToast,
}) => {
  const [secondsLeft, setSecondsLeft] = useState(14 * 60 + 59);

  useEffect(() => {
    const id = window.setInterval(() => {
      setSecondsLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => window.clearInterval(id);
  }, []);

  const handleSaveQr = () => {
    onShowToast('Kode QR TitipCerita siap disimpan ke galeri.');
  };

  return (
    <div className="px-5 pt-2 pb-10 md:px-0">
      <TopBar
        title="Bayar dengan QRIS"
        onBack={onBack}
        onMore={() => onShowToast('Scan menggunakan GoPay, OVO, DANA, atau m-banking.')}
      />

      {/* Mint Timer Banner */}
      <div className="bg-[#DFEFE8] rounded-[22px] p-4 flex items-start gap-3 mt-1 mb-5">
        <ScanLine className="w-5 h-5 text-[#182334] shrink-0 mt-0.5" strokeWidth={1.8} />
        <div>
          <div className="text-[13.5px] font-bold text-[#182334] tabular-nums">
            Kode berlaku {formatTimer(secondsLeft)}
          </div>
          <p className="text-[12.5px] text-[#334155] mt-1 leading-relaxed">
            Scan kode dari aplikasi e-wallet atau m-banking pilihanmu.
          </p>
        </div>
      </div>

      {/* QR Code Card */}
      <div className="tc-card px-6 py-6 flex flex-col items-center text-center mb-6">
        <div className="text-[16px] font-extrabold text-[#182334] mb-4">
          TitipCerita
        </div>

        <div className="p-2 rounded-2xl bg-white">
          <QrisIllustrationSvg className="w-48 h-48" />
        </div>

        <p className="text-[11px] text-[#64748B] mt-3">
          Kode ilustrasi · bukan untuk transaksi
        </p>

        <div className="text-[26px] font-extrabold text-[#182334] tracking-tight tabular-nums mt-2">
          {formatRupiah(draft.price)}
        </div>
        <p className="text-[12.5px] text-[#526071] mt-1">
          {draft.type} dengan {draft.buddyName} · {draft.durationLabel}
        </p>
      </div>

      {/* Instructions */}
      <div className="px-1 mb-5">
        <h3 className="text-[16px] font-extrabold text-[#182334]">
          Scan, cek, lalu konfirmasi.
        </h3>
        <p className="text-[13px] text-[#475569] leading-relaxed mt-1.5">
          Pastikan penerima TitipCerita dan nominal {formatRupiah(draft.price)} sebelum menyelesaikan pembayaran.
        </p>
      </div>

      {/* Actions */}
      <div className="space-y-3">
        <button
          type="button"
          onClick={handleSaveQr}
          className="w-full h-12 rounded-full bg-white hover:bg-slate-50 border border-slate-200/80 flex items-center justify-center gap-2 text-[14px] font-bold text-[#182334] transition-colors cursor-pointer"
        >
          <Download className="w-4 h-4 text-[#475569]" />
          <span>Simpan kode QR</span>
        </button>

        <button
          type="button"
          onClick={onConfirmPayment}
          className="w-full h-13 rounded-full tc-btn-primary text-[15px] cursor-pointer"
        >
          Cek status pembayaran
        </button>
      </div>

      <button
        type="button"
        onClick={onChangeMethod}
        className="mt-4 w-full py-2 text-[13px] font-semibold text-[#334155] hover:text-[#182334] cursor-pointer"
      >
        Ganti metode pembayaran
      </button>
    </div>
  );
};
