import React, { useState } from 'react';
import {
  ArrowRight,
  Clock,
  HeartHandshake,
  MessageCircle,
  Star,
  Timer,
} from 'lucide-react';
import { BuddyAvatar, DuoMascots } from '../components/assets/Mascots';
import { BUDDIES, formatRupiah, formatTimer } from '../data/mockData';
import { Buddy, SessionItem, SessionType } from '../types';

interface HomePageProps {
  userName: string;
  ongoingSession?: SessionItem;
  studySession?: SessionItem;
  onStartBooking: (buddy: Buddy, type: SessionType, timeLabel: string) => void;
  onEnterRoom: (session: SessionItem) => void;
  onOpenBantuanProfesional: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  userName,
  ongoingSession,
  studySession,
  onStartBooking,
  onEnterRoom,
  onOpenBantuanProfesional,
}) => {
  const [selectedModes, setSelectedModes] = useState<Record<string, SessionType>>({
    nara: 'Chat',
    dimas: 'Study',
    klara: 'Chat',
  });
  const [selectedSlots, setSelectedSlots] = useState<Record<string, string>>({
    nara: '19.00–19.30 WIB',
    dimas: '20.00–21.00 WIB',
    klara: '18.30–19.00 WIB',
  });

  return (
    <div className="px-5 pt-4 pb-6 md:px-0">
      {/* Hero Greeting */}
      <div className="flex items-center justify-between gap-4 mb-5">
        <div>
          <p className="text-[13px] font-semibold text-[#526071]">
            TitipCerita · Ruang sebaya yang aman
          </p>
          <h1 className="text-[28px] md:text-[32px] font-extrabold text-[#182334] tracking-tight leading-[1.15] mt-1">
            Hai, {userName}. Mau cerita atau fokus hari ini?
          </h1>
        </div>
        <div className="hidden sm:block shrink-0">
          <DuoMascots className="w-36 h-20" />
        </div>
      </div>

      {/* Quick Active / Study Shortcuts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 mb-6">
        {ongoingSession && (
          <div className="bg-[#DCE4FA] rounded-[24px] p-4 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <BuddyAvatar variant={ongoingSession.buddyMascot} size="md" />
              <div className="min-w-0">
                <div className="text-[13.5px] font-extrabold text-[#182334] truncate">
                  Sesi dengan {ongoingSession.buddyName} berlangsung
                </div>
                <div className="flex items-center gap-1.5 text-[12px] text-[#334155] tabular-nums mt-0.5">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Sisa waktu {formatTimer(ongoingSession.remainingSeconds)}</span>
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => onEnterRoom(ongoingSession)}
              className="px-4 h-10 rounded-full tc-btn-primary text-[12.5px] shrink-0 cursor-pointer"
            >
              Masuk chat
            </button>
          </div>
        )}

        {studySession && (
          <div className="bg-[#DFEFE8] rounded-[24px] p-4 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <BuddyAvatar variant={studySession.buddyMascot} size="md" />
              <div className="min-w-0">
                <div className="text-[13.5px] font-extrabold text-[#182334] truncate">
                  Study Room Pomodoro · {studySession.buddyName}
                </div>
                <div className="flex items-center gap-1.5 text-[12px] text-[#334155] mt-0.5">
                  <Timer className="w-3.5 h-3.5" />
                  <span>Fokus 25 menit · Istirahat 5 menit</span>
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => onEnterRoom(studySession)}
              className="px-4 h-10 rounded-full bg-white hover:bg-slate-50 text-[#182334] font-bold text-[12.5px] shrink-0 cursor-pointer shadow-xs"
            >
              Buka Pomodoro
            </button>
          </div>
        )}
      </div>

      {/* Buddy Selection */}
      <div className="flex items-center justify-between mb-3.5">
        <h2 className="text-[18px] font-extrabold text-[#182334] tracking-tight">
          Pilih teman sebayamu
        </h2>
        <span className="text-[12.5px] text-[#526071]">
          Terverifikasi · Privat
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        {BUDDIES.map((buddy) => {
          const mode = selectedModes[buddy.id] ?? 'Chat';
          const slot = selectedSlots[buddy.id] ?? buddy.availableSlots[0];
          const price = mode === 'Chat' ? buddy.chatPrice30 : buddy.studyPrice60;
          const durationText = mode === 'Chat' ? '30 menit' : '1 jam';

          return (
            <article
              key={buddy.id}
              className="tc-card p-5 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <BuddyAvatar variant={buddy.mascot} size="lg" />
                    <div>
                      <div className="text-[17px] font-extrabold text-[#182334]">
                        {buddy.name} ✓
                      </div>
                      <div className="text-[12px] text-[#526071]">
                        {buddy.role}
                      </div>
                    </div>
                  </div>
                  <div className="inline-flex items-center gap-1 text-[12.5px] font-bold text-[#182334] tabular-nums">
                    <Star className="w-3.5 h-3.5 fill-[#182334] text-[#182334]" />
                    <span>{buddy.rating}</span>
                  </div>
                </div>

                <p className="text-[13px] text-[#475569] leading-relaxed mt-3">
                  {buddy.bio}
                </p>

                <div className="flex flex-wrap gap-1.5 mt-3">
                  {buddy.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-3 py-1 rounded-full bg-[#F2F5FB] text-[11.5px] font-semibold text-[#334155]"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Mode Switcher */}
                <div className="grid grid-cols-2 gap-1.5 bg-[#F4F7FC] p-1 rounded-full mt-4">
                  <button
                    type="button"
                    onClick={() =>
                      setSelectedModes((prev) => ({ ...prev, [buddy.id]: 'Chat' }))
                    }
                    className={`py-2 rounded-full text-[12px] font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                      mode === 'Chat'
                        ? 'bg-white text-[#182334] shadow-xs'
                        : 'text-[#526071]'
                    }`}
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>Chat · 30m</span>
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setSelectedModes((prev) => ({ ...prev, [buddy.id]: 'Study' }))
                    }
                    className={`py-2 rounded-full text-[12px] font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                      mode === 'Study'
                        ? 'bg-white text-[#182334] shadow-xs'
                        : 'text-[#526071]'
                    }`}
                  >
                    <Timer className="w-3.5 h-3.5" />
                    <span>Study · 1j</span>
                  </button>
                </div>

                {/* Time Slots */}
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {buddy.availableSlots.map((timeSlot) => (
                    <button
                      key={timeSlot}
                      type="button"
                      onClick={() =>
                        setSelectedSlots((prev) => ({ ...prev, [buddy.id]: timeSlot }))
                      }
                      className={`px-2.5 py-1 rounded-full text-[11px] font-semibold border transition-colors cursor-pointer ${
                        slot === timeSlot
                          ? 'bg-[#DCE4FA] border-[#93A8E6] text-[#182334]'
                          : 'bg-white border-slate-200 text-[#526071]'
                      }`}
                    >
                      {timeSlot}
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[12px] text-[#526071]">
                    {mode} · {durationText}
                  </span>
                  <span className="text-[16px] font-extrabold text-[#182334] tabular-nums">
                    {formatRupiah(price)}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => onStartBooking(buddy, mode, slot)}
                  className="w-full h-11 rounded-full tc-btn-primary flex items-center justify-center gap-2 text-[13.5px] cursor-pointer"
                >
                  <span>Pesan sesi</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </article>
          );
        })}
      </div>

      {/* Safety Banner */}
      <button
        type="button"
        onClick={onOpenBantuanProfesional}
        className="w-full bg-[#F7D7CE] hover:bg-[#F3C9BD] rounded-[24px] p-4 flex items-center justify-between gap-3 text-left transition-colors cursor-pointer"
      >
        <div className="flex items-center gap-3">
          <HeartHandshake className="w-5 h-5 text-[#182334] shrink-0" />
          <div>
            <div className="text-[14px] font-bold text-[#182334]">
              Butuh bantuan profesional sekarang?
            </div>
            <div className="text-[12px] text-[#334155]">
              Akses layanan Healing119.id Kemenkes RI dan direktori psikolog berizin.
            </div>
          </div>
        </div>
        <ArrowRight className="w-4 h-4 text-[#182334] shrink-0" />
      </button>
    </div>
  );
};
