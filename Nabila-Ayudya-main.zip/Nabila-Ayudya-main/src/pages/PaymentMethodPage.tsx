import React from 'react';
import {
  CheckCircle2,
  ChevronRight,
  Landmark,
  Lock,
  ScanLine,
  Wallet,
} from 'lucide-react';
import { BuddyAvatar } from '../components/assets/Mascots';
import { TopBar } from '../components/common/TopBar';
import { formatRupiah } from '../data/mockData';
import { BookingDraft, EwalletProvider, PaymentMethodId } from '../types';

interface PaymentMethodPageProps {
  draft: BookingDraft;
  userName: string;
  onUpdateDraft: (patch: Partial<BookingDraft>) => void;
  onBack: () => void;
  onProceed: () => void;
  onShowToast: (msg: string) => void;
}

const EWALLET_PROVIDERS: EwalletProvider[] = ['GoPay', 'OVO', 'DANA'];

export const PaymentMethodPage: React.FC<PaymentMethodPageProps> = ({
  draft,
  userName,
  onUpdateDraft,
  onBack,
  onProceed,
  onShowToast,
}) => {
  const selectMethod = (method: PaymentMethodId) => {
    onUpdateDraft({ paymentMethod: method });
  };

  return (
    <div className="px-5 pt-2 pb-10 md:px-0">
      <TopBar
        title="Pembayaran"
        onBack={onBack}
        onMore={() => onShowToast('Semua transaksi tanpa biaya tambahan.')}
      />

      <div className="mt-2 mb-5">
        <h2 className="text-[28px] md:text-[32px] font-extrabold text-[#182334] tracking-tight leading-[1.15]">
          Selangkah lagi, {userName}.
        </h2>
        <p className="text-[13.5px] text-[#475569] mt-1.5">
          Cek sesimu, lalu pilih cara bayar.
        </p>
      </div>

      {/* Session Summary Card */}
      <div className="tc-card p-5 mb-6">
        <div className="flex items-center gap-3.5">
          <BuddyAvatar variant={draft.buddyMascot} size="lg" />
          <div>
            <div className="text-[16px] font-extrabold text-[#182334]">
              {draft.buddyName} · {draft.type}
            </div>
            <div className="text-[12.5px] text-[#526071] mt-0.5">
              {draft.dateLabel} · {draft.timeLabel}
            </div>
          </div>
        </div>
        <div className="flex items-center justify-between mt-4 pt-1">
          <span className="text-[13px] text-[#475569]">
            {draft.durationLabel}
          </span>
          <span className="text-[17px] font-extrabold text-[#182334] tabular-nums">
            {formatRupiah(draft.price)}
          </span>
        </div>
      </div>

      {/* Payment Methods */}
      <h3 className="text-[16px] font-extrabold text-[#182334] mb-3">
        Metode pembayaran
      </h3>

      <div className="space-y-3">
        {/* E-wallet */}
        <div
          className={`rounded-[22px] transition-all border ${
            draft.paymentMethod === 'ewallet'
              ? 'bg-[#DCE4FA] border-[#93A8E6]'
              : 'bg-white border-transparent shadow-[0_4px_20px_rgba(24,35,52,0.04)]'
          }`}
        >
          <button
            type="button"
            onClick={() => selectMethod('ewallet')}
            className="w-full p-4 flex items-center justify-between text-left cursor-pointer"
          >
            <div className="flex items-center gap-3.5">
              <Wallet className="w-5 h-5 text-[#182334] shrink-0" strokeWidth={1.7} />
              <div>
                <div className="text-[15px] font-extrabold text-[#182334]">
                  E-wallet
                </div>
                <div className="text-[12.5px] text-[#475569] mt-0.5">
                  {draft.ewalletProvider} ·{' '}
                  {draft.paymentMethod === 'ewallet' ? 'Dipilih' : 'Instan'}
                </div>
              </div>
            </div>
            {draft.paymentMethod === 'ewallet' ? (
              <CheckCircle2 className="w-5 h-5 text-[#182334] shrink-0" strokeWidth={1.8} />
            ) : (
              <ChevronRight className="w-4 h-4 text-[#64748B] shrink-0" />
            )}
          </button>

          {draft.paymentMethod === 'ewallet' && (
            <div className="px-4 pb-3.5 flex items-center gap-2">
              {EWALLET_PROVIDERS.map((provider) => (
                <button
                  key={provider}
                  type="button"
                  onClick={() => onUpdateDraft({ ewalletProvider: provider })}
                  className={`px-3 py-1 rounded-full text-[12px] font-bold transition-colors cursor-pointer ${
                    draft.ewalletProvider === provider
                      ? 'bg-[#182334] text-white'
                      : 'bg-white/75 text-[#334155] hover:bg-white'
                  }`}
                >
                  {provider}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Transfer bank */}
        <button
          type="button"
          onClick={() => selectMethod('bank')}
          className={`w-full rounded-[22px] p-4 flex items-center justify-between text-left transition-all border cursor-pointer ${
            draft.paymentMethod === 'bank'
              ? 'bg-[#DCE4FA] border-[#93A8E6]'
              : 'bg-white border-transparent shadow-[0_4px_20px_rgba(24,35,52,0.04)] hover:bg-white/90'
          }`}
        >
          <div className="flex items-center gap-3.5">
            <Landmark className="w-5 h-5 text-[#182334] shrink-0" strokeWidth={1.7} />
            <div>
              <div className="text-[15px] font-extrabold text-[#182334]">
                Transfer bank
              </div>
              <div className="text-[12.5px] text-[#475569] mt-0.5">
                Virtual account {draft.paymentMethod === 'bank' ? '· Dipilih' : ''}
              </div>
            </div>
          </div>
          {draft.paymentMethod === 'bank' ? (
            <CheckCircle2 className="w-5 h-5 text-[#182334] shrink-0" strokeWidth={1.8} />
          ) : (
            <ChevronRight className="w-4 h-4 text-[#64748B] shrink-0" />
          )}
        </button>

        {/* QRIS */}
        <button
          type="button"
          onClick={() => selectMethod('qris')}
          className={`w-full rounded-[22px] p-4 flex items-center justify-between text-left transition-all border cursor-pointer ${
            draft.paymentMethod === 'qris'
              ? 'bg-[#DCE4FA] border-[#93A8E6]'
              : 'bg-white border-transparent shadow-[0_4px_20px_rgba(24,35,52,0.04)] hover:bg-white/90'
          }`}
        >
          <div className="flex items-center gap-3.5">
            <ScanLine className="w-5 h-5 text-[#182334] shrink-0" strokeWidth={1.7} />
            <div>
              <div className="text-[15px] font-extrabold text-[#182334]">
                QRIS
              </div>
              <div className="text-[12.5px] text-[#475569] mt-0.5">
                Scan dari aplikasi pembayaranmu{' '}
                {draft.paymentMethod === 'qris' ? '· Dipilih' : ''}
              </div>
            </div>
          </div>
          {draft.paymentMethod === 'qris' ? (
            <CheckCircle2 className="w-5 h-5 text-[#182334] shrink-0" strokeWidth={1.8} />
          ) : (
            <ChevronRight className="w-4 h-4 text-[#64748B] shrink-0" />
          )}
        </button>
      </div>

      {/* Total Row */}
      <div className="flex items-center justify-between mt-6 mb-4 px-1">
        <span className="text-[13px] text-[#334155]">
          Total · tanpa biaya tambahan
        </span>
        <span className="text-[18px] font-extrabold text-[#182334] tabular-nums">
          {formatRupiah(draft.price)}
        </span>
      </div>

      {/* Pay CTA */}
      <button
        type="button"
        onClick={onProceed}
        className="w-full h-13 rounded-full tc-btn-primary flex items-center justify-center gap-2 text-[15px] cursor-pointer"
      >
        <Lock className="w-4 h-4" />
        <span>Bayar {formatRupiah(draft.price)}</span>
      </button>

      <div className="text-center mt-4 space-y-2.5 px-2">
        <p className="text-[12px] text-[#475569]">
          {draft.paymentMethod === 'ewallet' &&
            `Kamu akan diarahkan ke ${draft.ewalletProvider} untuk konfirmasi.`}
          {draft.paymentMethod === 'bank' &&
            'Nomor BCA Virtual Account akan disiapkan di langkah berikutnya.'}
          {draft.paymentMethod === 'qris' &&
            'Kode QRIS akan ditampilkan untuk kamu scan di aplikasi pembayaran.'}
        </p>
        <p className="text-[11px] leading-relaxed text-[#64748B]">
          Dengan melanjutkan, kamu menyetujui ketentuan pemesanan dan pembayaran.
        </p>
      </div>
    </div>
  );
};
