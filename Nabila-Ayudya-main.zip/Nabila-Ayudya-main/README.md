# TitipCerita

Aplikasi web **TitipCerita** — ruang teman cerita sebaya (*peer buddy*) dan sesi belajar Pomodoro yang aman, hangat, dan menjaga privasi.

## Fitur Utama

- **Sesi Saya (`Akan Datang`, `Berlangsung`, `Selesai`)**: Kelola jadwal sesi, masuk kembali ke ruang chat/belajar aktif dengan penghitung waktu mundur (*live countdown*), ubah jadwal, atau pesan ulang buddy yang sama.
- **Chat Room (Sesi Aktif)**: Percakapan real-time dengan *typing indicator*, kalimat pembuka cepat, tombol akhiri sesi kapan pun, dan akses cepat ke Bantuan Profesional.
- **Study Room (Pomodoro)**: Pengatur waktu fokus 25 menit dan istirahat 5 menit dengan *progress ring* interaktif, kontrol jeda/lanjut, serta obrolan progres bersama buddy.
- **Rating & Ulasan (`Gimana rasanya tadi?`)**: Lembar ulasan dengan bintang 1–5, tag pengalaman (`Pendengar baik`, `Tidak menghakimi`), komentar berpenghitung karakter, dan opsi nama samaran.
- **Alur Pembayaran Lengkap**: Pemilihan metode pembayaran (`E-wallet` GoPay/OVO/DANA, `Transfer bank` BCA Virtual Account dengan salin nomor VA & timer 15 menit, dan `QRIS`), hingga halaman konfirmasi pembayaran berhasil.
- **Bantuan Profesional**: Akses cepat layanan krisis **Healing119.id** Kementerian Kesehatan RI (Telepon 119 ekstensi 8 & WhatsApp), panduan bahaya medis segera, direktori psikolog berizin & Puskesmas/RS terdekat, serta panduan jeda napas.
- **Profil, Pengaturan & Privasi**: Edit profil dan karakter maskot, kelola minat (`Hal yang aku suka`), toggle notifikasi sesi, daftar akun diblokir, serta panel **Privasi ada di tanganmu** (unduh salinan data akun JSON, panduan komunitas, kebijakan privasi).
- **Home & Komunitas**: Pencarian buddy terverifikasi dan papan cerita komunitas anonim.

## Struktur Proyek

```text
src/
├── components/
│   ├── assets/         # Ilustrasi SVG karakter maskot & QRIS
│   ├── common/         # TopBar & Toast notification
│   ├── layout/         # AppShell responsif (mobile floating pill nav + desktop rail)
│   └── modals/         # ReviewSheet, PrivacySheet, SessionDetailSheet
├── data/               # Data awal buddy, sesi, direktori layanan, dan helper format
├── hooks/              # usePersistentState (sinkronisasi localStorage)
├── pages/              # Seluruh halaman aplikasi
├── types/              # Definisi tipe TypeScript
├── App.tsx             # State utama & navigasi antar layar
├── index.css           # Konfigurasi Tailwind CSS & token desain TitipCerita
└── main.tsx            # Entry point React
```

## Menjalankan Secara Lokal

```bash
# 1. Pasang dependensi
npm install

# 2. Jalankan server pengembangan
npm run dev

# 3. Pemeriksaan tipe TypeScript & build produksi
npm run lint
npm run build
```
